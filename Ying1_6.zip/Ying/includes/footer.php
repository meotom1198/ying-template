<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>

    </div>
</div>

<footer id="footer" role="contentinfo">
    <div class="footer">
        <div class="footer-info">
            <div class="footer-top wd-100">
                <div class="xcenter fr2">
                    <span class="social-item cursor hint--top hint--rounded" aria-label="Facebook: <?php echo $this->options->facebook ?>"><i class="fa fa-facebook" aria-hidden="true"></i></span>
                    <span class="social-item cursor hint--top hint--rounded" aria-label="Telegram: <?php echo $this->options->telegram ?>"><i class="fa fa-telegram" aria-hidden="true"></i></span>
                    <span class="social-item cursor hint--top hint--rounded" aria-label="Github: <?php echo $this->options->github ?>"><i class="fa fa-github" aria-hidden="true"></i></span>
                </div>
                <div class="footer-left fl1">
                    <div class="c5">
                        <div class="fcenter">
                            <?php foreach (array_filter(explode(PHP_EOL, $this->options->footerLinks)) as $uitem) : ?>
                                <a href="<?php echo trim(explode("$",$uitem)[1]); ?>"><?php echo trim(explode("$",$uitem)[0]); ?></a>
                            <?php endforeach; ?>
                            
                            <a class="hide38" target="_blank" href="http://beian.miit.gov.cn">|&nbsp;<img style="height:1rem;position: relative;top:2px;display: inherit;" src="<?php $this->options->themeUrl('img/icp.png'); ?>" />&nbsp;<?php $this->options->CopyRight(); ?></a>
                        </div>

                        <span class="typed-text"><?php $this->options->typed_text(); ?></span>                        
                    </div>
                    <a class="show38 xcenter" target="_blank" href="http://beian.miit.gov.cn"><img style="height:1rem;position: relative;top:2px;display: inherit;" src="<?php $this->options->themeUrl('img/icp.png'); ?>" />&nbsp;<?php $this->options->beian(); ?></a>
					<div class="typed-cursor"><span id="typed"></span></div>
                </div>
                <div class="footer-right fr1">
                    <span class="social-item cursor hint--top hint--rounded" aria-label="Facebook: <?php echo $this->options->facebook ?>"><i class="fa fa-facebook" aria-hidden="true"></i></span>
                    <span class="social-item cursor hint--top hint--rounded" aria-label="Telegram: <?php echo $this->options->telegram ?>"><i class="fa fa-telegram" aria-hidden="true"></i></span>
                    <span class="social-item cursor hint--top hint--rounded" aria-label="Github: <?php echo $this->options->github ?>"><i class="fa fa-github" aria-hidden="true"></i></span>
                </div>
            </div>
            <div class="footer-bottom" align="center">              
            <p id="time">Trang web của Hữu Phương đang tải dữ liệu...</p>
            <?php $this->options->title();?> • Powered by <a href="http://www.typecho.org">Typecho</a></div>
            </div>

        </div>

    </div>

</footer>

<div id="extra-pane">
    <?php $this->need('./component/extrapane.php'); ?>
    <div class="md-overlay"></div>
    <div class="filetype" data-list="<?php echo $this->options->fileType; ?>"></div>
</div>

<div>
    <script src="<?php $this->options->themeUrl('assets/js/ying.min.js'); ?>"></script>
    <script src="<?php $this->options->themeUrl('assets/js/main.js'); ?>?v<?php echo rand(10000, 99999); ?>"></script>
    <script src="<?php $this->options->themeUrl('assets/js/fancybox.umd.js'); ?>"></script>
    <script src="<?php $this->options->themeUrl('assets/js/colpick.min.js'); ?>"></script>
</div>
<script  type="text/javascript">
    var colorStr="";
    var randomArr=['0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f'];
    for(var i=0;i<6;i++){
        colorStr+=randomArr[Math.ceil(Math.random()*(15-0)+0)];
    }
    var now =new Date(); 
    function StorageTime() { 
        var grt= new Date("12/12/2022 18:45:00");
        now.setTime(now.getTime()+250); 
        years = Math.floor((now - grt ) / 1000 / 60 / 60 / 24 /365);
        days = Math.floor((now - grt ) / 1000 / 60 / 60 / 24 - (years * 365)); 
        hours = Math.floor((now - grt ) / 1000 / 60 / 60 - (24 * Math.floor((now - grt ) / 1000 / 60 / 60 / 24)));
        if(String(hours).length ==1 ){hours = "0" + hours;} 
        minutes = Math.floor((now - grt ) / 1000 /60 - (24 * 60 * Math.floor((now - grt ) / 1000 / 60 / 60 / 24)) - (60 * hours));
        if(String(minutes).length ==1 ){minutes = "0" + minutes;}
        seconds = Math.floor((now - grt ) / 1000 - (24 * 60 * 60 * Math.floor((now - grt ) / 1000 / 60 / 60 / 24)) - (60 * 60 * hours) - (60 * minutes)); 
        if(String(seconds).length ==1 ){seconds = "0" + seconds;}
        if(years!=0){var outputtime="Thời gian hoạt động: <span>"+years+"</span> năm "+"<span>"+days+"</span> ngày "+"<span>"+hours+"</span> giờ "+"<span>"+minutes+"</span> phút"+"<span>"+seconds+"</span> giây";}else{var outputtime="Thời gian hoạt động: <span>"+days+"</span> ngày "+"<span>"+hours+"</span> giờ "+"<span>"+minutes+"</span> phút "+"<span>"+seconds+"</span> giây";}
        document.getElementById("time").style.color="#"+colorStr;
        document.getElementById("time").innerHTML = outputtime;
    } 
    setInterval("StorageTime()",250);

<?php echo $this->options->diyjs ?>
</script>
<?php $this->footer(); ?>
</body>
</html>