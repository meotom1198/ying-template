<?php

/**
 * Liên kết
 * 
 * @package custom 
 * 
 **/
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
$this->need('includes/header.php');
?>
<link rel="stylesheet" href="<?php $this->options->themeUrl('assets/css/joe.mode.min.css'); ?>">
<link rel="stylesheet" href="<?php $this->options->themeUrl('assets/css/joe.global.min.css'); ?>">
<link rel="stylesheet" href="<?php $this->options->themeUrl('assets/css/fancybox.min.css'); ?>">
<link rel="stylesheet" href="<?php $this->options->themeUrl('assets/css/HLstyle/default.min.css'); ?>">
<link rel="stylesheet" href="<?php $this->options->themeUrl('assets/css/post.min.css'); ?>?v<?php echo rand(10000, 99999); ?>">
<link rel="stylesheet" href="https://fastly.jsdelivr.net/npm/aplayer@1.10.1/dist/APlayer.min.css">
<?php Typecho_Widget::widget('Widget_Stat')->to($stat); ?>
        <div style="display: none;">
       <?php if ($this->options->JPrismTheme) : ?>
          <link rel="stylesheet" href="<?php $this->options->JPrismTheme() ?>">
        <?php else : ?>
        <link rel="stylesheet" href="https://fastly.jsdelivr.net/npm/prismjs@1.23.0/themes/prism.min.css">
    <?php endif; ?>
    <script src="https://fastly.jsdelivr.net/npm/typecho-joe-next@6.2.4/plugin/prism/prism.min.js"></script>
    </div>
<div class="col-mb-12 col-8" id="main" role="main">
<div class="archive-bg">
        <div class="diy-archive-bg wh-100" style="background-image: url(<?php if($this->fields->cover){echo $this->fields->cover;}else{echo $this->options->coverimg;} ?>);">
            <div class="about-page-name">
                    <?php $this->title(); ?>
            </div> 
            <span class="default-cover"><?php echo $this->options->coverimg ?></span>
            <div class="aner"></div>
        </div>
</div>
<div class="layout-page">
    <div class="page">
    <article  class="page-post ab-article" itemscope itemtype="http://schema.org/BlogPosting">
        <div class="about-row">
            <div class="ab-side hide7">
                <div class="xcenter">
                    <ul class="user-info">
                    <li><span class="user-tags c-blue hint--top" aria-label="Có <?php $stat->publishedPostsNum() ?> bài viết">
                        <i class="fa fa-file-text-o x5" aria-hidden="true"></i><?php $stat->publishedPostsNum() ?>
                    </span></li>
                    <li><span class="user-tags c-yellow hint--top" aria-label="Có <?php $stat->publishedCommentsNum() ?> lượt bình luận">
                        <i class="fa fa-commenting-o x5" aria-hidden="true"></i><?php $stat->publishedCommentsNum() ?></i>
                    </span></li>
                    <li><span class="user-tags c-green hint--top" aria-label="<?php $stat->categoriesNum() ?>chuyên mục">
                        <i class="fa fa-bar-chart x5" aria-hidden="true"></i> <?php $stat->categoriesNum() ?></i>
                    </span></li>
                    <li><span class="user-tags c-red hint--top" aria-label="Tổng số từ của trang web: <?php allOfCharacters(); ?>">
                        <i class="fa fa-file-word-o x5" aria-hidden="true"></i><?php allOfCharacters(); ?></i>
                    </span></li>
                    </ul>
                </div>
            </div>
            <div class="ab-center">
                <div class="ab-avatar-box">
                    <img class="ab-avatar xcenter" src="<?php echo $this->options->avatar?>"  alt="About">
                </div>
                <div class="ab-name">
                    <h2 class="xcenter"><?php $this->options->title() ?></h2>
                    
                </div>
            </div>
            <div class="ab-side hide7">
                <div class="xcenter">
                    <ul class="ab-link">
                    <li class="ab-item qq cursor hint--top hint--rounded" aria-label="Facebook: <?php echo $this->options->facebook ?>"><i class="fa fa-facebook" aria-hidden="true"></i></li>
                    <li class="ab-item weixin cursor hint--top hint--rounded" aria-label="Telegram: <?php echo $this->options->telegram ?>"><i class="fa fa-telegram" aria-hidden="true"></i></li>
                    <li class="ab-item github cursor hint--top hint--rounded" aria-label="Github<?php echo $this->user->mail ?>"><i class="fa fa-github" aria-hidden="true"></i></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="ab-desc"><span class="xcenter"><?php $this->options->description() ?></span></div>
        <div class="ab-show7">
            <div class="ab7">
                <div class="xcenter">
                    <ul class="user-info">
                    <li><span class="user-tags c-blue hint--top" aria-label="Đã đăng <?php $stat->publishedPostsNum() ?> bài viết">
                        <i class="fa fa-file-text-o x5" aria-hidden="true"></i><?php $stat->publishedPostsNum() ?>
                    </span></li>
                    <li><span class="user-tags c-yellow hint--top" aria-label="<?php $stat->publishedCommentsNum() ?> lượt bình luận">
                        <i class="fa fa-commenting-o x5" aria-hidden="true"></i><?php $stat->publishedCommentsNum() ?></i>
                    </span></li>
                    <li><span class="user-tags c-green hint--top" aria-label="<?php $stat->categoriesNum() ?> chuyên mục">
                        <i class="fa fa-bar-chart x5" aria-hidden="true"></i> <?php $stat->categoriesNum() ?></i>
                    </span></li>
                    <li><span class="user-tags c-red hint--top" aria-label="Tổng số từ của trang web:<?php allOfCharacters(); ?>">
                        <i class="fa fa-file-word-o x5" aria-hidden="true"></i><?php allOfCharacters(); ?></i>
                    </span></li>
                    </ul>
                </div>
            </div>

            <div class="ab7">
                <div class="xcenter">
                    <ul class="ab-link">
                    <li class="ab-item qq cursor hint--top hint--rounded" aria-label="Facebook: <?php echo $this->options->facebook ?>"><i class="fa fa-facebook" aria-hidden="true"></i></li>
                    <li class="ab-item weixin cursor hint--top hint--rounded" aria-label="Telegram: <?php echo $this->options->telegram ?>"><i class="fa fa-telegram" aria-hidden="true"></i></li>
                    <li class="ab-item github cursor hint--top hint--rounded" aria-label="Github: <?php echo $this->user->github ?>"><i class="fa fa-github" aria-hidden="true"></i></li>
                    </ul>
                </div>
            </div>                
        </div>
        <div class="ab-post">
        <div id="article" class="pcontent" itemprop="articleBody">
        <?php echo _parseContent($this,$this->user->hasLogin());?>


<?php
                    $friends = [];
                    $friends_text = $this->options->JFriends;
                    if ($friends_text) {
                        $friends_arr = explode("\r\n", $friends_text);
                        if (count($friends_arr) > 0) {
                            for ($i = 0; $i < count($friends_arr); $i++) {
                                $name = explode("||", $friends_arr[$i])[0];
                                $url = explode("||", $friends_arr[$i])[1];
                                $avatar = explode("||", $friends_arr[$i])[2];
                                $desc = explode("||", $friends_arr[$i])[3];
                                $friends[] = array("name" => trim($name), "url" => trim($url), "avatar" => trim($avatar), "desc" => trim($desc));
                            };
                        }
                    }
                    ?>
                    <?php if (sizeof($friends) > 0) : ?>
                        <div class="grid grid-cols-2 sm:grid-cols-3 2xl:grid-cols-4 gap-4">
                            <?php foreach ($friends as $item) : ?>
                                <div style="margin-top:10px;" class="group sm:flex items-center p-4 bg-white shadow-md sm:shadow-lg rounded-md border border-gray-100 text-gray-600 bg-white dark:text-gray-400 dark:bg-gray-600 dark:border-gray-600 transition-all duration-300 transform hover:shadow-2xl hover:-translate-y-1 relative overflow-hidden">
                                    <img src="<?php echo $item['avatar']; ?>" class="w-11 h-11 sm:w-14 sm:h-14 object-cover rounded-full scrollLoading ojbk" alt="<?php echo $item['name']; ?>">
        <div class="w-full mt-2 sm:mt-0 sm:pl-4">
            <p class="text-base font-medium line-1 transition-all duration-300 transform dark:text-gray-50 group-hover:text-red-500 dark:hover:text-red-500"><a href="<?php echo $item['url']; ?>" target="_blank" rel="noopener noreferrer" title="<?php echo $item['name']; ?>" class="block"><?php echo $item['name']; ?></a>
            </p>
            <p class="text-xs text-gray-400 line-1 mt-1"><?php echo $item['desc']; ?></p>
        </div>
        <div class="absolute -bottom-10 -right-10 w-32 h-32 sm:w-24 sm:h-24 rounded-full bg-contain opacity-5 duration-300 group-hover:opacity-10" style="background-image:url(<?php echo $item['avatar']; ?>);"></div>
    </div>
                            <?php endforeach; ?>
                        </div></div>
                    <?php endif; ?>
        </div>
        </div>
    </article>
    <div class="comment-box cts">
     <?php $this->need('comments.php'); ?>
    </div>
    </div>
    </div>
</div>
<script src="<?php $this->options->themeUrl('assets/js/joe.short.min.js'); ?>"></script>
<script src="https://fastly.jsdelivr.net/npm/aplayer@1.10.1/dist/APlayer.min.js"></script>
<?php $this->need('./includes/footer.php'); ?>
