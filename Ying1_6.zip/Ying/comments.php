<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>

<?php function threadedComments($comments, $options) {
    $commentClass = '';$sf="<i class=\"mdi mdi-account-outline\"></i> Khách";
    if ($comments->authorId) {
        if ($comments->authorId == $comments->ownerId) {$sf="<i class=\"mdi mdi-account-check\"></i> Admin";$commentClass .= ' comment-by-author';  
        }else{$commentClass .= ' comment-by-user';$sf="<i class=\"mdi mdi-account-box\"></i> Thành viên";}} 
    $commentLevelClass = $comments->_levels > 0 ? ' comment-child' : ' comment-parent';  //评论层数大于0为子级，否则是父级?>
<div id="li-<?php $comments->theId(); ?>" class="comment-body<?php 
	if ($comments->levels > 0) {echo ' comment-child';$comments->levelsAlt(' comment-level-odd', ' comment-level-even');
	} else {echo ' comment-parent hang';}
	$comments->alt(' comment-odd', ' comment-even');
    if ($comments->url) {$author = '<a href="' . $comments->url . '" target="_blank" rel="external nofollow">' . $comments->author . '</a>';
    } else {$author = '<span>' . $comments->authowr . '</span>';}?>">
<div class="cot-body">
	<div class="cot-head">
		<img class="com-avatar" src="<?php comavatar($comments->mail,0,$comments->coid); ?>">
		<div class="media-body">
			<div class="cot-head-left ycenter">
			<span class="mt-0"><?php echo $author; ?>&nbsp;<?php if ('waiting' == $comments->status) { ?><span class="text-muted">Đợi Admin duyệt nhé!</span><?php } ?> <span class=""><svg class="ying" aria-hidden="true"><use xlink:href="#ying-wode"></use></svg><?php echo $sf; ?></span> <?php getOs($comments->agent); ?><?php getBrowser($comments->agent); ?></span>
			<p class="text-muted">
				<span class=""><svg class="ying" aria-hidden="true"><use xlink:href="#ying-shijian"></use></svg>&nbsp;<?php echo time_diff($comments->created);?></span>
			</p>
			</div>
			<div class="cot-head-right">
			<?php Typecho_Widget::widget('Widget_Security')->to($security); ?>
			<?php global$login; if($login): ?>
			<a href="<?php $security->index('/action/comments-edit?do=delete&coid=' . $comments->coid); ?>" class=" operate-delete" onclick="javascript:return cot_del()"><svg class="ying" aria-hidden="true"><use xlink:href="#ying-shanchu"></use></svg>&nbsp;</a>
			<?php endif; ?>
			<span id="reply" class="comment-reply cp-<?php $comments->theId(); ?>"  >&nbsp;<?php $comments->reply('<svg class="ying" aria-hidden="true"><use xlink:href="#ying-at"></use></svg>'); ?></span>
			</div>
		</div>
	</div>
	
	<div class="cot-content">
	<?php $cots=parseBiaoQing($comments->content);$cots = preg_replace('#<a(.*?) href="([^"]*/)?(([^"/]*)\.[^"]*)"(.*?)>#','<a$1 href="$2$3"$5 target="_blank" rel="nofollow">', $cots);echo get_comment_at($comments->coid).$cots;?>
		</div>
	<div id="<?php $comments->theId(); ?>" class="mt-1"></div>
</div>
<?php if ($comments->children) { ?>
<div style="border-bottom:1px;" class="comment-children">

    <?php $comments->threadedComments($options); ?>
</div>
<?php } ?>
</div>
<?php } ?>
<div id="comments" class="comments">
	<?php $this->comments()->to($comments); ?>
	
          <?php if($this->allow('comment')): ?>
    <div id="<?php $this->respondId(); ?>" class="respond">
        <div class="cancel-comment-reply"><?php $comments->cancelReply(); ?></div>
    <div class="commet-box">
	<form method="post" action="<?php $this->commentUrl() ?>" id="comment-form" role="form">

		<div class="comment-content">
		<div class="comment-row">

				<?php if($this->user->hasLogin()): ?>
					<?php global$login; $login = true; ?>
			    <div class="comment-col"> <div class="comment-form-group"> <input type="text" name="author" maxlength="12" id="author" class="form-control" placeholder="Tên*" value="<?php $this->user->screenName(); ?>" required=""> </div>
		        </div> 
		        <div class="comment-col"> <div class="comment-form-group"> <input type="email" name="mail" id="mail" class="form-control" placeholder="Email*" value="<?php $this->user->mail(); ?>" <?php if ($this->options->commentsRequireMail): ?> class="required"<?php endif; ?>> </div> 
		        </div> 
		        <div class="comment-col"> <div class="comment-form-group"> <input type="url" name="url" id="url" class="form-control" placeholder="URL(http://)" value="<?php $this->options->siteUrl(); ?>" <?php if ($this->options->commentsRequireURL): ?> required<?php endif; ?>>  </div> 
		        </div> 
		        <?php else: ?>
		        <div class="comment-col"> <div class="comment-form-group"> <input type="text" name="author" maxlength="12" id="author" class="form-control" placeholder="Tên*" value="<?php $this->remember('author'); ?>" required=""> </div>
		        </div> 
		         <div class="comment-col"> <div class="comment-form-group"> <input type="email" name="mail" id="mail" class="form-control" placeholder="Email*" value="<?php $this->remember('mail'); ?>" <?php if ($this->options->commentsRequireMail): ?> class="required"<?php endif; ?>> </div> 
		        </div> 
		        <div class="comment-col"> <div class="comment-form-group"> <input type="url" name="url" id="url" class="form-control" placeholder="URL(http://)" value="<?php $this->remember('url'); ?>" <?php if ($this->options->commentsRequireURL): ?> required<?php endif; ?>>  </div> 
		        </div> 
		        <?php endif;?>
		    </div>
		
		<textarea class="form-textarea form-control-light mb-2 OwO-textarea" name="text" placeholder="Nói gì đó đi..." id="example-textarea" rows="7" required=""><?php $this->remember('text'); ?></textarea>
		<div class="comment-bottom">
		<a href="javascript: void(0);"class="OwO-logo" rel="external nofollow"><i class="fa fa-smile-o" aria-hidden="true"></i></a>
		<button type="submit" class="Qmsg btn btn-primary cursor btn-sm submit " id="misubmit"><svg class="ying" aria-hidden="true"><use xlink:href="#ying-xiaoxi"></use></svg> Gửi bình luận</button>
		</div>
		<!-- <span id="cancel_reply" class="cancel-comment-reply cl-<?php $comments->theId(); ?>"><?php $comments->cancelReply('<i class="fa fa-reply" aria-hidden="true"></i>&nbsp;Hủy bỏ'); ?></span> -->
		
		<?php $security = $this->widget('Widget_Security'); ?><input type="hidden" name="_" value="<?php echo $security->getToken($this->request->getReferer())?>">
		<div class="OwO-box"><div class="OwO"></div></div>
		</div>
    	</form>
	</div>
    </div>
    <?php else: ?>
    <h3><?php _e('Đã tắt bình luận!'); ?></h3>
    <?php endif; ?>
     <?php if ($comments->have()): ?>
	<h3><svg class="ying" aria-hidden="true"><use xlink:href="#ying-xiaoxi"></use></svg> <?php $this->commentsNum(_t('Chưa có bình luận nào!'), _t('Có 1 bình luận'), _t('Có %d bình luận')); ?></h3>
    <?php $comments->listComments(); ?>
    <?php $comments->pageNav('&laquo; Trang trước', 'Trang sau &raquo;'); ?>
    <?php endif; ?>
</div>
    <script src="<?php $this->options->themeUrl('assets/OwO/OwO.min.js'); ?>" data-no-instant></script>