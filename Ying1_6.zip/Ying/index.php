<?php

/**
 * <div style="color:#2997f7;">Chủ đề Ying - Đơn giản, responsive, thân thiện,... Phù hợp cho Blog đa phương tiện.</div>
 * 
 * @package Ying
 * @author Hữu Phương
 * @version 1.6
 * @link https://all4vn.cf/
 */
if (!defined('__TYPECHO_ROOT_DIR__')) exit;$this->need('./includes/header.php');?>

<?php if($this->options->tbon == "On"):?>
<script type="text/javascript">
/* Dust Encounter-Thông báo */
function cookiesave(n, v, mins, dn, path)
{
    if (n)
    {
        if (!mins) {
            mins = 24 * 60;
        }
        if (!path) {
            path = "/";
        }
        var date = new Date();
        date.setTime(date.getTime() + (mins * 60 * 1000));
        var expires = "; expires=" + date.toGMTString();
        if (dn) {
            dn = "domain=" + dn + "; ";
        }
        document.cookie = n + "=" + v + expires + "; " + dn + "path=" + path;
    }
}
function cookieget(n)
{
    var name = n + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++)
    {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1, c.length);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return ""
}
function closeclick()
{
    document.getElementById('note').style.display = 'none';
    cookiesave('closeclick', 'closeclick', '', '', '')
}
function clickclose()
{
    if (cookieget('closeclick') == 'closeclick') {
        document.getElementById('note').style.display = 'none'
    }
    else {
        document.getElementById('note').style.display = 'block';
    }
}
window.onload = clickclose;
</script>
<div class="popup" id="note" style="display:none;">
    <div class="popup-icon"><img src="https://cdn.jsdelivr.net/gh/cy-i/chenyu@1.0.0/img/cyhome.svg"></div>
    <div class="popup-header">
        <h3 class="popup-title">Một thế giới - Một ước mơ</h3>
    </div>
    <div class="popup-main"><?php echo $this->options->tb ?></div>
    <div class="popup-footer"><span class="popup-btn" onclick="closeclick()">Tôi hiểu rồi!</span></div>
</div>
<?php endif; ?>

<div class="layout-page">
<?php if ($this->options->index_layout == "layout2") {$this->need('./component/slides.php');} ?>
<div class="index-content">
	<?php if ($this->options->sider_layout == "layout2" && $this->options->sideWidget) {$this->need('./includes/sidebar.php');} ?>
	<div class="index-layout">
		<?php if ($this->options->index_layout == "layout1") {$this->need('./component/slides.php');} ?>
		<?php $this->need('./component/tagspage.php'); ?>
		<?php $this->need('./component/postlist.php'); ?>
	<?php if ( $this->options->footnew && $this->is('index') ): ?>
<?php $this->need('./component/img-list.php'); ?>
<?php endif; ?>	

	</div>
	<?php if ($this->options->sider_layout == "layout1" && $this->options->sideWidget) {$this->need('./includes/sidebar.php');} ?>
</div>
</div>

<?php $this->need('./includes/footer.php'); ?>
