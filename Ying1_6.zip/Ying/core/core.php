<?php

/* Chức năng công cộng */
require_once('function.php');

/* Chức năng lọc nội dung */
require_once('short.php');

/* Phương pháp plugin */
require_once('factory.php');

/* Phương pháp plugin */
require_once('parse.php');

//Thống kê chữ Hán
function allOfCharacters()
{
    $showPrivate = intval($pluginOpts->showPrivate);
    $chars = 0;
    $db = Typecho_Db::get();
    if ($showPrivate == 0) {
        $select = $db->select('text')->from('table.contents')->where('table.contents.status = ?', 'publish');
    } else {
        $select = $db->select('text')->from('table.contents');
    }
    $rows = $db->fetchAll($select);
    foreach ($rows as $row) {
        $text = preg_replace("/[^\x{4e00}-\x{9fa5}]/u", "", $row['text']); //Lọc tiếng Trung
        $chars += mb_strlen($text, 'UTF-8');
    }
    $unit = '';
    if ($chars >= 10000) {
        $chars /= 10000;
        $unit = 'w';
    } else if ($chars >= 1000) {
        $chars /= 1000;
        $unit = 'k';
    }
    $out = sprintf('%.2lf %s', $chars, $unit);
    echo $out;
}

function art_count($cid)
{
    $db = Typecho_Db::get();
    $rs = $db->fetchRow($db->select('table.contents.text')->from('table.contents')->where('table.contents.cid=?', $cid)->order('table.contents.cid', Typecho_Db::SORT_ASC)->limit(1));
    $rel_text = preg_replace("/[^\x{4e00}-\x{9fa5}]/u", "", $rs['text']);
    echo mb_strlen($rel_text, 'UTF-8');
}

function slide_ctrl()
{
    $db = Typecho_Db::get();
    $query = $db->select('cid')->from('table.fields')->where('str_value = ?', 'Yes')->where('name = ?', 'slide');
    $result = $db->fetchAll($query);
    return $result;
}

// Hiển thị ảnh bìa
function showCover($widget)
{
    $options = Typecho_Widget::widget('Widget_Options');
    if (($widget->fields->cover)) {
        $img = $widget->fields->cover;
    } else {
        $img = $options->coverimg;
    }
    return $img;
}

// Cụm từ ngẫu nhiên
function duanju()
{
    $options = Typecho_Widget::widget('Widget_Options');
    $arr = file($options->themeUrl('/assets/word.txt', "Ying"));
    $n = rand(0, count($arr) - 1);
    echo $arr[$n];
}
// Lục giác sang RGB
  function hex2rgb($hexColor) {
    $color = str_replace('#', '', $hexColor);
    if (strlen($color) > 3) {
      $rgb = array(
        'r' => hexdec(substr($color, 0, 2)),
        'g' => hexdec(substr($color, 2, 2)),
        'b' => hexdec(substr($color, 4, 2))
      );
    } else {
      $color = $hexColor;
      $r = substr($color, 0, 1) . substr($color, 0, 1);
      $g = substr($color, 1, 1) . substr($color, 1, 1);
      $b = substr($color, 2, 1) . substr($color, 2, 1);
      $rgb = array(
        'r' => hexdec($r),
        'g' => hexdec($g),
        'b' => hexdec($b)
      );
    }
    return $rgb;
  }
  // RGB sang hệ thập lục phân
function rgb2hex($rgb){
    $regexp = "/^rgb\(([0-9]{0,3})\,\s*([0-9]{0,3})\,\s*([0-9]{0,3})\)/";
    $re = preg_match($regexp, $rgb, $match);
    $re = array_shift($match);
    $hexColor = "#";
    $hex = array('0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F');
    for ($i = 0; $i < 3; $i++) {
      $r = null;
      $c = $match[$i];
      $hexAr = array();
      while ($c > 16) {
        $r = $c % 16;
        $c = ($c / 16) >> 0;
        array_push($hexAr, $hex[$r]);
      }
      array_push($hexAr, $hex[$c]);
      $ret = array_reverse($hexAr);
      $item = implode('', $ret);
      $item = str_pad($item, 2, '0', STR_PAD_LEFT);
      $hexColor .= $item;
    }
    return $hexColor;
  }
// Khung thời gian
function Time_range()
{
    $time = time();
    $newtime = date('d-m-Y');
    $ctime = strtotime(date($newtime . '18:00' . ':00'));
    $etime = strtotime(date($newtime . '06:00' . ':00'));
    if ($time >= $ctime || $time <= $etime) {
        return true;
    } else {
        return false;
    }
}
// Chuyển đổi chế độ ngày và đêm
function Switch_day()
{
    if (Time_range()) {
        setcookie("auto_night", "1");
        return true;
    } else {
        setcookie("auto_night", "0");
        // setcookie('auto_night', "",time()-3660);
        return false;

    }
}

// Nhận ghim bài viết
function getTopPost(){
    $db = Typecho_Db::get();
    $result = $db->fetchAll($db->select('cid')->from('table.fields')
        ->where('name = ?','topPost')
        ->where('str_value = ?', 'Yes')
        ->order('cid', Typecho_Db::SORT_DESC)
    );
    $postArr = array();
    foreach ($result as $post) {
        $postArr[] = $post['cid'];
    }
    return $postArr;
}
// Nhận thông tin cập nhật mới nhất
function recentUpdate($limit){
    $db = Typecho_Db::get();
    $result = $db->fetchAll($db->select('cid')->from('table.contents')
        ->where('status = ?','publish')
        ->where('type = ?', 'post')
        ->where('password is NULL')
        ->where('created <= unix_timestamp(now())', 'post') 
        ->limit($limit)
        ->order('modified', Typecho_Db::SORT_DESC)
    );
    return $result;
}
// Nhận các bài viết phổ biến
function getHotcomts($limit){
    $db = Typecho_Db::get();
    $result = $db->fetchAll($db->select('cid')->from('table.contents')
        ->where('status = ?','publish')
        ->where('type = ?', 'post')
        ->where('password is NULL')
        ->where('created <= unix_timestamp(now())', 'post') 
        ->limit($limit)
        ->order('commentsNum', Typecho_Db::SORT_DESC)
    );
    return $result;
}
// Nhận 10 bài viết có nhiều lượt xem nhất
function getHotviews($limit){
    $db = Typecho_Db::get();
        if (!array_key_exists('views', $db->fetchRow($db->select()->from('table.contents')))) {
        $db->query('ALTER TABLE `'.$db->getPrefix().'contents` ADD `views` INT(10) DEFAULT 0;');
    }
    $result = $db->fetchAll($db->select('cid')->from('table.contents')
        ->where('status = ?','publish')
        ->where('type = ?', 'post')
        ->where('password is NULL')
        ->where('created <= unix_timestamp(now())', 'post') 
        ->limit($limit)
        ->order('views', Typecho_Db::SORT_DESC)
    );
    return $result;
}

// Bài viết ngẫu nhiên
function random_posts($limit){
    $db = Typecho_Db::get();
    $rand = "RAND()";
    if (stripos($db->getAdapterName(), 'sqlite') !== false) {
        $rand = "RANDOM()";
    }

    $suery = $db->select()->from('table.contents')
        ->where('status = ?', 'publish')
        ->where('type = ?', 'post')
        ->where('password is NULL')
        ->where('created <= ' . Helper::options()->gmtTime, 'post') 
        ->limit($limit)
        ->order($rand);
    $result = $db->fetchAll($suery);
    return $result;
}
function getUpdateTime($cid){
    $db = Typecho_Db::get();
    $time = $db->fetchAll($db->select('modified')->from('table.contents')
        ->where('status = ?','publish')
        ->where('type = ?', 'post')
        ->where('cid = ?', $cid)
    )[0]['modified'];
    return $time;
}

// Thống kê lượt xem bài viết
function Postviews($archive) {

    $db = Typecho_Db::get();
    $cid = $archive->cid;
    if (!array_key_exists('views', $db->fetchRow($db->select()->from('table.contents')))) {
        $db->query('ALTER TABLE `'.$db->getPrefix().'contents` ADD `views` INT(10) DEFAULT 0;');
    }
    $views = $db->fetchRow($db->select('views')->from('table.contents')->where('cid = ?', $cid))['views'];
    if ($archive->is('single')) {
        $cookie = Typecho_Cookie::get('contents_views');
        $cookie = $cookie ? explode(',', $cookie) : array();
        if (!in_array($cid, $cookie)) {
            $db->query($db->update('table.contents')
                ->rows(array('views' => (int)$views+1))
                ->where('cid = ?', $cid));
            $views = (int)$views+1;
            array_push($cookie, $cid);
            $cookie = implode(',', $cookie);
            Typecho_Cookie::set('contents_views', $cookie,time()+60 * 20);
        }
    }
}

// Truy vấn lượt xem bài viết
function getViews($cid){
    $db = Typecho_Db::get();
    if (!array_key_exists('views', $db->fetchRow($db->select()->from('table.contents')))) {
        $db->query('ALTER TABLE `'.$db->getPrefix().'contents` ADD `views` INT(10) DEFAULT 0;');
    }
    $views = $db->fetchRow($db->select('views')->from('table.contents')->where('cid = ?', $cid))['views'];
    return $views;
}

// Thời gian trước
function timesince($older_date)
{
    if ($older_date == "no") {
        return;
    }
    $chunks = array(
        array(86400, ' ngày'),
        array(3600, ' giờ'),
        array(60, ' phút'),
        array(1, ' giây'),
    );
    $newer_date = time();
    $since = abs($newer_date - $older_date);
    for ($i = 0, $j = count($chunks); $i < $j; $i++) {
        $seconds = $chunks[$i][0];
        $name = $chunks[$i][1];
        if (($count = floor($since / $seconds)) != 0) break;
    }
    $output = $count . $name . ' trước';
    return $output;
}

// Tính chênh lệch múi giờ
function time_diff($start)
{
    $datetime_start = new DateTime(date("d-m-Y", $start));
    $datetime_end = new DateTime(date("d-m-Y", time()));
    $days = $datetime_start->diff($datetime_end)->days;
    if($days > 30){
        return date('d-m-Y',$start);
    }else{
        return timesince($start);
    }
}
// Đang tải lựa chọn hoạt hình
function loadingStyle($style1,$style2){
    if($style1 == $style2){
        echo "loading-show";
    }else{
        echo "loading-hidden";
    }
}

function getContent($cid){
    $db = Typecho_Db::get();
    $select = $db->select('text')->from('table.contents')->where('cid = ?', $cid);
    $content =  $db->fetchRow($select)['text'];
    return $content;
}

// Thích bài viết
function ThumbUp($cid) {
    $db = Typecho_Db::get();
    $ThumbUp = $db->fetchRow($db->select('table.contents.ThumbUp')->from('table.contents')->where('cid = ?', $cid));
    $ThumbUpRecording = Typecho_Cookie::get('typechoThumbUpRecording');
    if (empty($ThumbUpRecording)) {
        Typecho_Cookie::set('typechoThumbUpRecording', json_encode(array($cid)));
    }else {
        $ThumbUpRecording = json_decode($ThumbUpRecording);
        if (in_array($cid, $ThumbUpRecording)) {
            return $ThumbUp['ThumbUp'];
        }
        array_push($ThumbUpRecording, $cid);
        Typecho_Cookie::set('typechoThumbUpRecording', json_encode($ThumbUpRecording));
    }
    $db->query($db->update('table.contents')->rows(array('ThumbUp' => (int)$ThumbUp['ThumbUp'] + 1))->where('cid = ?', $cid));
    $ThumbUp = $db->fetchRow($db->select('table.contents.ThumbUp')->from('table.contents')->where('cid = ?', $cid));
    return $ThumbUp['ThumbUp'];
}

// Nhận lượt thích bài viết
function getThumbUps($cid) {
    $db = Typecho_Db::get();
    $prefix = $db->getPrefix();

    if (!array_key_exists('ThumbUp', $db->fetchRow($db->select()->from('table.contents')))) {
        $db->query('ALTER TABLE `' . $prefix . 'contents` ADD `ThumbUp` INT(10) NOT NULL DEFAULT 0;');
    }
    $ThumbUp = $db->fetchRow($db->select('table.contents.ThumbUp')->from('table.contents')->where('cid = ?', $cid));
    $ThumbUpRecording = Typecho_Cookie::get('typechoThumbUpRecording');
    if (empty($ThumbUpRecording)) {
        Typecho_Cookie::set('typechoThumbUpRecording', json_encode(array(0)));
    }
    return array(
        'ThumbUp' => $ThumbUp['ThumbUp'],
        'recording' => in_array($cid, json_decode(Typecho_Cookie::get('typechoThumbUpRecording')))?true:false
    );
}


function echart_data($data_arr) {
    $data_arr = array_reverse($data_arr);
    $time1 = strtotime('-1 month',strtotime($data_arr[0])); 
    $time2 = strtotime($data_arr[count($data_arr)-1]);
    $monstr = "";
    $monarr = array();
    while( ($time1 = strtotime('+1 month',$time1)) <= $time2){
        $monarr[] = date('m-Y',$time1); 
        $monstr .= date('m-Y',$time1) .','; 
    }
    $monstr = substr($monstr,0,strlen($monstr)-1);
    $sarr = array_count_values($data_arr);
    $numstr = "";
    for ($i=0;$i<count($monarr);$i++){
        if($sarr[$monarr[$i]]){
            $numstr .= $sarr[$monarr[$i]].',';
        }else{
            $numstr .= '0'.',';
        }
    }
    $numstr = substr($numstr,0,strlen($numstr)-1);
    $earry = array();
    array_push($earry,$monstr,$numstr);
    return $earry;
    }
// Cài đặt màu chủ đề
function themeColor($color) {
    $db = Typecho_Db::get();
    $db->query($db->update('table.options')->rows(array('value' => $color))->where('name = ?', 'Color:Ying'));
}
function getThemeColor(){
    $db = Typecho_Db::get();
    if(!$db->fetchRow($db->select('value')->from('table.options')->where('name = ?', 'Color:Ying'))){
        $insert = $db->query($db->insert('table.options')->rows(array('name' => 'Color:Ying','value' => '#000000')));
        }
    $themeColor = $db->fetchRow($db->select('value')->from('table.options')->where('name = ?', 'Color:Ying'))['value'];
    return $themeColor;
}
// Cài đặt thuộc tính bài viết
function Postset($cid,$indent,$slide,$topPost,$title,$cover,$keyword,$desc){
    $options = Typecho_Widget::widget('Widget_Options');
    $default_cover = $options->coverimg;
    $db = Typecho_Db::get();
    if(!empty($db->fetchRow($db->select('name')->from('table.fields')->where('cid = ?', $cid)->where('name = ?', 'indent')))){$db->query($db->update('table.fields')->rows(array('str_value' => $indent))->where('cid = ?', $cid)->where('name = ?','indent'));}else{$db->query($db->insert('table.fields')->rows(array('cid' => $cid,'name' => 'indent', 'str_value' => $indent)));  }
    if(!empty($db->fetchRow($db->select('name')->from('table.fields')->where('cid = ?', $cid)->where('name = ?', 'slide')))){
        $db->query($db->update('table.fields')->rows(array('str_value' => $slide))->where('cid = ?', $cid)->where('name = ?','slide'));}else{$db->query($db->insert('table.fields')->rows(array('cid' => $cid,'name' => 'slide', 'str_value' => $slide)));}
    if(!empty($db->fetchRow($db->select('name')->from('table.fields')->where('cid = ?', $cid)->where('name = ?', 'topPost')))){$db->query($db->update('table.fields')->rows(array('str_value' => $topPost))->where('cid = ?', $cid)->where('name = ?','topPost'));}else{$db->query($db->insert('table.fields')->rows(array('cid' => $cid,'name' => 'topPost', 'str_value' => $topPost)));}
    $db->query($db->update('table.contents')->rows(array('title' => $title))->where('cid = ?', $cid));  
    $db->query($db->update('table.fields')->rows(array('str_value' => $cover))->where('cid = ?', $cid)->where('name = ?','cover'));    
    $db->query($db->update('table.fields')->rows(array('str_value' => $keyword))->where('cid = ?', $cid)->where('name = ?','keyword'));    
    $db->query($db->update('table.fields')->rows(array('str_value' => $desc))->where('cid = ?', $cid)->where('name = ?','description'));
}

// Cài đặt thuộc tính phân loại
function arcSet($mid,$arc_name,$cover_url,$arc_icon,$arc_desc) {
    $options = Typecho_Widget::widget('Widget_Options');
    $default_cover = $options->coverimg;
    $db = Typecho_Db::get();
    $prefix = $db->getPrefix();
    // ALTER TABLE `typecho_metas` DROP COLUMN `cover`;
    if (!array_key_exists('cover', $db->fetchRow($db->select()->from('table.metas')))) {
        $db->query('ALTER TABLE `' . $prefix . 'metas` ADD `cover` varchar(200) NOT NULL DEFAULT "'.$default_cover.'";');
    }
    if (!array_key_exists('icon', $db->fetchRow($db->select()->from('table.metas')))) {
        $db->query('ALTER TABLE `' . $prefix . 'metas` ADD `icon` varchar(200) NOT NULL DEFAULT "";');
    }
    $db->query($db->update('table.metas')->rows(array('name' => $arc_name))->where('mid = ?', $mid));
    $db->query($db->update('table.metas')->rows(array('cover' => $cover_url))->where('mid = ?', $mid));
    $db->query($db->update('table.metas')->rows(array('icon' => $arc_icon))->where('mid = ?', $mid));
    $db->query($db->update('table.metas')->rows(array('description' => $arc_desc))->where('mid = ?', $mid));
}

// Cài đặt trang
function PageSet($cid,$cover_url,$icon) {
    $db = Typecho_Db::get();
    $db->query($db->update('table.fields')
        ->rows(array('str_value' => $cover_url))
        ->where('name = ?', 'cover')
        ->where('cid = ?', $cid));
    $db->query($db->update('table.fields')
        ->rows(array('str_value' => $icon))
        ->where('name = ?', 'icon')
        ->where('cid = ?', $cid));
}

function getTables(){
    $db = Typecho_Db::get();
    $prefix = $db->getPrefix();
    $tableArr = array();
    $tables = $db->query("show tables")->fetchAll();
    foreach($tables as $table){
        array_push($tableArr,$table['Tables_in_'.$db->getConfig()[0]->database]);
    }
    return $tableArr;
}
// OwO
function parsePaopaoBiaoqingCallback($match)
{
    return '<img class="biaoqing" src="/usr/themes/Ying/assets/OwO/owo/paopao/' . str_replace('%', '', urlencode($match[1])) . '_2x.png">';
}

function parseAruBiaoqingCallback($match)
{
    return '<img class="biaoqing" src="/usr/themes/Ying/assets/OwO/owo/aru/' . str_replace('%', '', urlencode($match[1])) . '_2x.png">';
}

function parseQuyinBiaoqingCallback($match)
{
    return '<img class="biaoqing" src="/usr/themes/Ying/assets/OwO/owo/quyin/' . str_replace('%', '', urlencode($match[1])) . '_2x.png">';
}

function parseadaiBiaoqingCallback($match)
{
    return '<img class="biaoqing" src="/usr/themes/Ying/assets/OwO/owo/adai/' . str_replace('%', '', urlencode($match[1])) . '.gif">';
}

function parseBiaoQing($content)
{
    $content = preg_replace_callback('/\:\:\(\s*(呵呵|哈哈|吐舌|惊恐|酷|发飙|嗯哼|流汗|大哭|尴尬|黑脸|超赞|金钱|疑问|尬脸|吐|哦豁|委屈|眯眼笑|哟嚯|超开心|滑稽|眨眼|羡慕|入眠|惊哭|气呼呼|震惊|喷水|爱心|心碎|玫瑰|礼物|咖啡|OK|小无奈|偷笑|坏笑|卧槽|要死|亚麻跌|笑哭了|犀利|理一下|坐端正|完美|吃瓜|摊手|困狗|靠墙看|发现|饮酒|忍笑|警告|炸黑|滑稽汗|打脸|胖次|低看)\s*\)/is',
        'parsePaopaoBiaoqingCallback', $content);

    $content = preg_replace_callback('/\:\*\(\s*(愤怒|装酷|委屈|鄙视|尴尬|魔鬼|惊恐|亲亲|喜欢|猪头|抠鼻|伤心|吃惊|微笑|邪笑|失落|冒汗|闭嘴)\s*\)/is',
        'parseadaiBiaoqingCallback', $content);

    $content = preg_replace_callback('/\:\@\(\s*(发火|羡慕|吐血倒地|吐血|抱抱|鼓掌|呆滞|流泪|嫌疑|灵魂出窍|囧|惊慌|流口水|送花花|不高兴|阴险|捅死你|暗中观察|哲学思考|无奈|嘟嘴|大佬|闭嘴|害羞|脸红|黑线|举白旗|赞|吐舌头)\s*\)/is',
        'parseAruBiaoqingCallback', $content);

    $content = preg_replace_callback('/\:\&\(\s*(蛆音滑稽|蛆音震惊|蛆音生气|蛆音吓哭|蛆音血躺|蛆音疑惑|蛆音捡肥皂|蛆音捂脸|蛆音吐血石化|蛆音哼气|蛆音大笑|蛆音偷看|蛆音卖萌|蛆音好的|蛆音惊吓|蛆音摇头|蛆音睡觉|蛆音无语|蛆音吃瓜|蛆音自恋)\s*\)/is',
        'parseQuyinBiaoqingCallback', $content);
    return $content;
}
function Parsepost($content){
    $content = preg_replace_callback('/\:\:\(\s*(呵呵|哈哈|吐舌|惊恐|酷|发飙|嗯哼|流汗|大哭|尴尬|黑脸|超赞|金钱|疑问|尬脸|吐|哦豁|委屈|眯眼笑|哟嚯|超开心|滑稽|眨眼|羡慕|入眠|惊哭|气呼呼|震惊|喷水|爱心|心碎|玫瑰|礼物|咖啡|OK|小无奈|偷笑|坏笑|卧槽|要死|亚麻跌|笑哭了|犀利|理一下|坐端正|完美|吃瓜|摊手|困狗|靠墙看|发现|饮酒|忍笑|警告|炸黑|滑稽汗|打脸|胖次|低看)\s*\)/is',
'parsePaopaoBiaoqingCallback', $content);
    $content = preg_replace_callback('/\:\@\(\s*(发火|羡慕|吐血倒地|吐血|抱抱|鼓掌|呆滞|流泪|嫌疑|灵魂出窍|囧|惊慌|流口水|送花花|不高兴|阴险|捅死你|暗中观察|哲学思考|无奈|嘟嘴|大佬|闭嘴|害羞|脸红|黑线|举白旗|赞|吐舌头)\s*\)/is',
'parseAruBiaoqingCallback', $content);
    $content = preg_replace_callback('/\:\&\(\s*(蛆音滑稽|蛆音震惊|蛆音生气|蛆音吓哭|蛆音血躺|蛆音疑惑|蛆音捡肥皂|蛆音捂脸|蛆音吐血石化|蛆音哼气|蛆音大笑|蛆音偷看|蛆音卖萌|蛆音好的|蛆音惊吓|蛆音摇头|蛆音睡觉|蛆音无语|蛆音吃瓜|蛆音自恋)\s*\)/is',
        'parseQuyinBiaoqingCallback', $content);
    return $content;
    $content = preg_replace_callback('/\:\*\(\s*(愤怒|装酷|委屈|鄙视|尴尬|魔鬼|惊恐|亲亲|喜欢|猪头|抠鼻|伤心|吃惊|微笑|邪笑|失落|冒汗|闭嘴)\s*\)/is',
        'parseadaiBiaoqingCallback', $content);
}

// Nhận thông tin trình duyệt
function getBrowser($agent)
{
    if (preg_match('/MSIE\s([^\s|;]+)/i', $agent, $regs)) {
        $outputer = '<i class="ua-icon icon-ie"></i>&nbsp;&nbsp;';
    } else if (preg_match('/FireFox\/([^\s]+)/i', $agent, $regs)) {
        $str1 = explode('Firefox/', $regs[0]);
        $FireFox_vern = explode('.', $str1[1]);
        $outputer = '<i class="ua-icon icon-firefox"></i>&nbsp;&nbsp;';
    } else if (preg_match('/Maxthon([\d]*)\/([^\s]+)/i', $agent, $regs)) {
        $str1 = explode('Maxthon/', $agent);
        $Maxthon_vern = explode('.', $str1[1]);
        $outputer = '<i class="ua-icon icon-edge"></i>&nbsp;&nbsp;';
    } else if (preg_match('#360([a-zA-Z0-9.]+)#i', $agent, $regs)) {
        $outputer = '<i class="ua-icon icon-360"></i>&nbsp;&nbsp;';
    } else if (preg_match('/Edge([\d]*)\/([^\s]+)/i', $agent, $regs)) {
        $str1 = explode('Edge/', $regs[0]);
        $Edge_vern = explode('.', $str1[1]);
        $outputer = '<i class="ua-icon icon-edge"></i>&nbsp;&nbsp;';
    } else if (preg_match('/UC/i', $agent)) {
        $str1 = explode('rowser/', $agent);
        $UCBrowser_vern = explode('.', $str1[1]);
        $outputer = '<i class="ua-icon icon-uc"></i>&nbsp;&nbsp;';
    } else if (preg_match('/QQ/i', $agent, $regs) || preg_match('/QQBrowser\/([^\s]+)/i', $agent, $regs)) {
        $str1 = explode('rowser/', $agent);
        $QQ_vern = explode('.', $str1[1]);
        $outputer = '<i class= "ua-icon icon-qqq"></i>&nbsp;&nbsp;';
    } else if (preg_match('/UBrowser/i', $agent, $regs)) {
        $str1 = explode('rowser/', $agent);
        $UCBrowser_vern = explode('.', $str1[1]);
        $outputer = '<i class="ua-icon icon-uc"></i>&nbsp;&nbsp;';
    } else if (preg_match('/Opera[\s|\/]([^\s]+)/i', $agent, $regs)) {
        $outputer = '<i class= "ua-icon icon-opera"></i>&nbsp;&nbsp;';
    } else if (preg_match('/Chrome([\d]*)\/([^\s]+)/i', $agent, $regs)) {
        $str1 = explode('Chrome/', $agent);
        $chrome_vern = explode('.', $str1[1]);
        $outputer = '<i class="ua-icon icon-chrome"></i>&nbsp;&nbsp;';
    } else if (preg_match('/safari\/([^\s]+)/i', $agent, $regs)) {
        $str1 = explode('Version/', $agent);
        $safari_vern = explode('.', $str1[1]);
        $outputer = '<i class="ua-icon icon-safari"></i>&nbsp;&nbsp;';
    } else {
        $outputer = '<i class="ua-icon icon-chrome"></i>&nbsp;&nbsp;';
    }
    echo $outputer;
}

// Lấy thông tin hệ điều hành
function getOs($agent)
{
    $os = false;

    if (preg_match('/win/i', $agent)) {
        if (preg_match('/nt 6.0/i', $agent)) {
            $os = '&nbsp;&nbsp;<i class= "ua-icon icon-win1"></i>&nbsp;&nbsp;&nbsp;/&nbsp;';
        } else if (preg_match('/nt 6.1/i', $agent)) {
            $os = '&nbsp;&nbsp;<i class= "ua-icon icon-win1"></i>&nbsp;&nbsp;&nbsp;/&nbsp;';
        } else if (preg_match('/nt 6.2/i', $agent)) {
            $os = '&nbsp;&nbsp;<i class="ua-icon icon-win2"></i>&nbsp;&nbsp;&nbsp;/&nbsp;';
        } else if (preg_match('/nt 6.3/i', $agent)) {
            $os = '&nbsp;&nbsp;<i class= "ua-icon icon-win2"></i>&nbsp;&nbsp;&nbsp;/&nbsp;';
        } else if (preg_match('/nt 5.1/i', $agent)) {
            $os = '&nbsp;&nbsp;<i class="ua-icon icon-win1"></i>&nbsp;&nbsp;&nbsp;/&nbsp;';
        } else if (preg_match('/nt 10.0/i', $agent)) {
            $os = '&nbsp;&nbsp;<i class="ua-icon icon-win2"></i>&nbsp;&nbsp;&nbsp;/&nbsp;';
        } else {
            $os = '&nbsp;&nbsp;<i class="ua-icon icon-win2"></i>&nbsp;&nbsp;&nbsp;/&nbsp;';
        }
    } else if (preg_match('/android/i', $agent)) {
        if (preg_match('/android 9/i', $agent)) {
            $os = '&nbsp;&nbsp;<i class="ua-icon icon-android"></i>&nbsp;&nbsp;&nbsp;/&nbsp;';
        } else if (preg_match('/android 8/i', $agent)) {
            $os = '&nbsp;&nbsp;<i class="ua-icon icon-android"></i>&nbsp;&nbsp;&nbsp;/&nbsp;';
        } else {
            $os = '&nbsp;&nbsp;<i class="ua-icon icon-android"></i>&nbsp;&nbsp;&nbsp;/&nbsp;';
        }
    } else if (preg_match('/ubuntu/i', $agent)) {
        $os = '&nbsp;&nbsp;<i class="ua-icon icon-ubuntu"></i>&nbsp;&nbsp;&nbsp;/&nbsp;';
    } else if (preg_match('/linux/i', $agent)) {
        $os = '&nbsp;&nbsp;<i class= "ua-icon icon-linux"></i>&nbsp;&nbsp;Linux&nbsp;/&nbsp;';
    } else if (preg_match('/iPhone/i', $agent)) {
        $os = '&nbsp;&nbsp;<i class="ua-icon icon-apple"></i>&nbsp;&nbsp;&nbsp;/&nbsp;';
    } else if (preg_match('/mac/i', $agent)) {
        $os = '&nbsp;&nbsp;<i class="ua-icon icon-mac"></i>&nbsp;&nbsp;&nbsp;/&nbsp;';
    } else if (preg_match('/fusion/i', $agent)) {
        $os = '&nbsp;&nbsp;<i class="ua-icon icon-android"></i>&nbsp;&nbsp;&nbsp;/&nbsp;';
    } else {
        $os = '&nbsp;&nbsp;<i class="ua-icon icon-linux"></i>&nbsp;&nbsp;&nbsp;/&nbsp;';
    }
    echo $os;
}

// Ảnh đại diện bình luận
function comavatar($mail,$id=0){
	$a=Typecho_Widget::widget('Widget_Options')->gravatars;
	$b='https://gravatar.loli.net/avatar'.$a.'/';
	$c=strtolower($mail);
	$d=md5($c);
	$f=str_replace('@qq.com','',$c);
	if(strstr($c,"qq.com")&&is_numeric($f)&&strlen($f)<11&&strlen($f)>4){
		$g='//q.qlogo.cn/g?b=qq&nk='.$f.'&s=100';
	}else{
		$g=$b.$d.'?d=mm';
        // $g=getrdqq(10);
	}
	echo $g;
}
function get_comment_at($coid){
    $db   = Typecho_Db::get();
    $prow = $db->fetchRow($db->select('parent')->from('table.comments')->where('coid = ?', $coid));
    $parent = $prow['parent'];
    if ($parent != "0") {
        $arow = $db->fetchRow($db->select('author')->from('table.comments')
                                     ->where('coid = ? AND status = ?', $parent, 'approved'));
if($arow['author']){ $author = $arow['author'];
        $href   = '<a href="#comment-' . $parent . '">@' . $author . '&nbsp;</a>';
        echo $href;
}else { echo '';}
    } else {
        echo '';
    }
}

function CommentAuthor($obj, $autoLink = NULL, $noFollow = NULL) {
	$options = Helper::options();
	$autoLink = $autoLink ? $autoLink : $options->commentsShowUrl;
	$noFollow = $noFollow ? $noFollow : $options->commentsUrlNofollow;
	if ($obj->url && $autoLink) {
		echo '<a href="'.$obj->url.'"'.($noFollow ? ' rel="external nofollow"' : NULL).(strstr($obj->url, $options->index) == $obj->url ? NULL : ' target="_blank"').'>'.$obj->author.'</a>';
	} else {
		echo $obj->author;
	}
}

function CommentAt($coid){
	$db = Typecho_Db::get();
	$prow = $db->fetchRow($db->select('parent')->from('table.comments')
		->where('coid = ? AND status = ?', $coid, 'approved'));
	$parent = $prow['parent'];
	if ($prow && $parent != '0') {
		$arow = $db->fetchRow($db->select('author')->from('table.comments')
			->where('coid = ? AND status = ?', $parent, 'approved'));
		echo '<b class="comment-at">@'.$arow['author'].'</b>';
	}
}

function Weekday(){
    $weekarray=array("CN","Thứ 2","Thứ 3","Thứ 4","Thứ 5","Thứ 6","Thứ 7");
    echo "".$weekarray[date("w")];
}

// Thư mục bài viết
function createCatalog($obj) {    //Thêm neo vào tiêu đề bài viết
    global $catalog;
    global $catalog_count;
    $catalog = array();
    $catalog_count = 0;
    $obj = preg_replace_callback('/<h([1-6])(.*?)>(.*?)<\/h\1>/i', function($obj) {
        global $catalog;
        global $catalog_count;
        $catalog_count ++;
        $catalog[] = array('text' => trim(strip_tags($obj[3])), 'depth' => $obj[1], 'count' => $catalog_count);
        return '<h'.$obj[1].$obj[2].'><a class="topmao" name="cl-'.$catalog_count.'"></a>'.$obj[3].'</h'.$obj[1].'>';
    }, $obj);
    return $obj;
}

//Đầu ra chứa thư mục bài viết
function getCatalog() {    
    global $catalog;
    if ($catalog) {
        $index = '<ul id="toc-container">';
        foreach($catalog as $catalog_item) {
            $count = $catalog_item['count'];
            $toc = $catalog_item['text'];
            $depth = $catalog_item['depth'];
            $index .= '<li class="toc-ctrl toc-s'.$depth.'"><a class="wh-100 toc-'.$depth.'" href="#cl-'.$count.'">'.$toc.'</a></li>';
        }
        $index .= '</ul>';
    echo $index;  
    }
}

function themeInit($archive) {
    if ($archive->is('single')) {
        $archive->content = createCatalog($archive->content);
    }
}

// Tiếp theo
function GtheNext($widget)
{
    $db = Typecho_Db::get();
    $sql = $db->select()->from('table.contents')
        ->where('table.contents.created > ?', $widget->created)
        ->where('table.contents.status = ?', 'publish')
        ->where('table.contents.type = ?', $widget->type)
        ->where('table.contents.password IS NULL')
        ->order('table.contents.created', Typecho_Db::SORT_ASC)
        ->limit(1);
    $content = $db->fetchRow($sql);
    if ($content) {
        $content = $widget->filter($content);
    }
    return $content;
}

// Trước
function GthePrev($widget, $word = '上一篇', $default = NULL)
{
    $db = Typecho_Db::get();
    $sql = $db->select()->from('table.contents')
        ->where('table.contents.created < ?', $widget->created)
        ->where('table.contents.status = ?', 'publish')
        ->where('table.contents.type = ?', $widget->type)
        ->where('table.contents.password IS NULL')
        ->order('table.contents.created', Typecho_Db::SORT_DESC)
        ->limit(1);
        $content = $db->fetchRow($sql);
        if ($content) {
            $content = $widget->filter($content);
        }
        return $content;
}

// Nén HTML
function compressHtml($html_source) {
	$chunks = preg_split('/(<!--<nocompress>-->.*?<!--<\/nocompress>-->|<nocompress>.*?<\/nocompress>|<pre.*?\/pre>|<textarea.*?\/textarea>|<script.*?\/script>)/msi', $html_source, -1, PREG_SPLIT_DELIM_CAPTURE);
	$compress = '';
	foreach ($chunks as $c) {
		if (strtolower(substr($c, 0, 19)) == '<!--<nocompress>-->') {
			$c = substr($c, 19, strlen($c) - 19 - 20);
			$compress .= $c;
			continue;
		} else if (strtolower(substr($c, 0, 12)) == '<nocompress>') {
			$c = substr($c, 12, strlen($c) - 12 - 13);
			$compress .= $c;
			continue;
		} else if (strtolower(substr($c, 0, 4)) == '<pre' || strtolower(substr($c, 0, 9)) == '<textarea') {
			$compress .= $c;
			continue;
		} else if (strtolower(substr($c, 0, 7)) == '<script' && strpos($c, '//') != false && (strpos($c, PHP_EOL) !== false || strpos($c, PHP_EOL) !== false)) {
			$tmps = preg_split('/(\r|\n)/ms', $c, -1, PREG_SPLIT_NO_EMPTY);
			$c = '';
			foreach ($tmps as $tmp) {
				if (strpos($tmp, '//') !== false) {
					if (substr(trim($tmp), 0, 2) == '//') {
						continue;
					}
					$chars = preg_split('//', $tmp, -1, PREG_SPLIT_NO_EMPTY);
					$is_quot = $is_apos = false;
					foreach ($chars as $key => $char) {
						if ($char == '"' && $chars[$key - 1] != '\\' && !$is_apos) {
							$is_quot = !$is_quot;
						} else if ($char == '\'' && $chars[$key - 1] != '\\' && !$is_quot) {
							$is_apos = !$is_apos;
						} else if ($char == '/' && $chars[$key + 1] == '/' && !$is_quot && !$is_apos) {
							$tmp = substr($tmp, 0, $key);
							break;
						}
					}
				}
				$c .= $tmp;
			}
		}
		$c = preg_replace('/[\\n\\r\\t]+/', ' ', $c);
		$c = preg_replace('/\\s{2,}/', ' ', $c);
		$c = preg_replace('/>\\s</', '> <', $c);
		$c = preg_replace('/\\/\\*.*?\\*\\//i', '', $c);
		$c = preg_replace('/<!--[^!]*-->/', '', $c);
		$compress .= $c;
	}
	return $compress;
}

//Lấy chuyên mục ra trang chủ
function getcateid($id){  //Nhận id chuyên mục
   $db = Typecho_Db::get();
   $postnum=$db->fetchRow($db->select()->from ('table.relationships')->where ('cid=?',$id));
   return  $postnum['mid']; 
}
//Lấy tên chuyên mục ra trang chủ
function catename($cateid){  //Lấy tên chuyên mục
   $db = Typecho_Db::get();
   $postnum=$db->fetchRow($db->select()->from ('table.metas')->where ('mid=?',$cateid)->where('type=?', 'category'));
   return  $postnum['name']; 
}

/**
* Có kích hoạt chức năng tăng tốc thay thế tên miền CDN hay không
*/
function stcdn($i) {
   $cdnopen = Helper::options()->cdnopen;
   $cdnurla = Helper::options()->cdnurla;
   $cdnurlb = Helper::options()->cdnurlb; 
   if ($cdnopen == '0'){
   $i = $i;
   return $i;
   }else {
   $i = str_replace($cdnurla,$cdnurlb,$i);
   return $i;
   } 
}
function stcdnimg($i) {
   $cdnopen = Helper::options()->cdnopen;
   $cdnurla = Helper::options()->cdnurla;
   $cdnurlb = Helper::options()->cdnurlb; 
   $imageView = Helper::options()->imageView;
   if ($cdnopen == '0'){
   $i = $i;
   return $i;
   }else {
   $i = str_replace($cdnurla,$cdnurlb,$i);
   return $i.$imageView;  
   } 
}

function GrabImage($url) {
    $folder = dirname(__FILE__).'/poster/';
    is_dir($folder) OR mkdir($folder, 0777, true);
    $filetype = explode(".",$url)[count(explode(".",$url))-1];
    $filename = 'poster.'.$filetype;
    $file= dirname(__FILE__).'/poster/'.$filename;
    if(file_exists($file)){
        unlink($file);
    }
    ob_start();
    readfile($url);
    $img = ob_get_contents();
    ob_end_clean();
    $fp2=@fopen(dirname(__FILE__).'/poster/'.$filename, "a");
    fwrite($fp2,$img);
    fclose($fp2);
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'; 
    $randomString = ''; 
    for ($i = 0; $i < 10; $i++) { 
        $index = rand(0, strlen($characters) - 1); 
        $randomString .= $characters[$index]; 
    } 
    return '/usr/themes/Ying/poster/'.$filename.'?'.$randomString;
    }
function AvaImage($url) {
    $filetype = explode(".",$url)[count(explode(".",$url))-1];
    $filename = 'avatar.'.$filetype;
    $file= dirname(__FILE__).'/poster/'.$filename;
    if(file_exists($file)){
        unlink($file);
    }
    ob_start();
    readfile($url);
    $img = ob_get_contents();
    ob_end_clean();
    $fp2=@fopen(dirname(__FILE__).'/poster/'.$filename, "a");
    fwrite($fp2,$img);
    fclose($fp2);
    return '/usr/themes/Ying/poster/'.$filename;
}

//Lấy bản đồ nội dung của bài viết
function getPostHtmImg($obj,$type='0') {
	preg_match_all( "/<[img|IMG].*?src=[\'|\"](.*?)[\'|\"].*?(alt=[\'|\"](.*?)[\'|\"].*?)?[\/]?>/", $obj->content, $matches);
	$atts = array();$n=0;
	if(isset($matches[1][0])) {
		for($i = 0; $i < count($matches[1]); $i++) {
		    $p=$i+1;
		    if(empty($matches[3][$i])){
		        $title=$obj->title.' '.$p;
		    }else{
		        $title=$matches[3][$i];
		    }
		    
			$atts[] = array('name' => $obj->title.' ['.($i + 1).']', 'url' => $matches[1][$i],'title' => $title);
			$n++;
		}
    }
    if($type=='num'){return $n;}else{
	return  count($atts) ? $atts : NULL;
}
}
function Postview($archive) {
    $db = Typecho_Db::get();
    $cid = $archive->cid;
    if (!array_key_exists('views', $db->fetchRow($db->select()->from('table.contents')))) {
        $db->query('ALTER TABLE `'.$db->getPrefix().'contents` ADD `views` INT(10) DEFAULT 0;');
    }
    $exist = $db->fetchRow($db->select('views')->from('table.contents')->where('cid = ?', $cid))['views'];
    if ($archive->is('single')) {
        $cookie = Typecho_Cookie::get('contents_views');
        $cookie = $cookie ? explode(',', $cookie) : array();
        if (!in_array($cid, $cookie)) {
            $db->query($db->update('table.contents')
                ->rows(array('views' => (int)$exist+1))
                ->where('cid = ?', $cid));
            $exist = (int)$exist+1;
            array_push($cookie, $cid);
            $cookie = implode(',', $cookie);
            Typecho_Cookie::set('contents_views', $cookie);
        }
    }
    
    if( $exist == 0 ){
      echo '0';
    }
    else{      
      $exist = convert($exist);
      echo $exist;
    }
}
function convert($num) 
{
    if ($num >= 100000)
    {
        $num = round($num / 10000) .'w';
    } 
    else if ($num >= 10000) 
    {
        $num = round($num / 10000, 1) .'w';
    } 
    else if($num >= 1000) 
    {
        $num = round($num / 1000, 1) . 'k';
    }
    return $num;
}
 ?>