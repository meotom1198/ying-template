<?php $name = "Ying";
$db = Typecho_Db::get();
if (isset($_POST['type'])) {
    if ($_POST["type"] == "Sao lưu cài đặt") {
        $value = $db->fetchRow($db->select()->from('table.options')->where('name = ?', 'theme:' . $name))['value'];
        if ($db->fetchRow($db->select()->from('table.options')->where('name = ?', 'theme:' . $name . '_backup'))) {
            $db->query($db->update('table.options')->rows(array('value' => $value))->where('name = ?', 'theme:' . $name . '_backup')); ?>
            <script>
                alert("Khôi phục sao lưu thành công!");
                window.location.href = '<?php Helper::options()->adminUrl('options-theme.php'); ?>'
            </script>
        <?php } else { ?>
            <?php
            if ($value) {
                $db->query($db->insert('table.options')->rows(array('name' => 'theme:' . $name . '_backup', 'user' => '0', 'value' => $value)));
            ?>
                <script>
                    alert("Sao lưu thành công!");
                    window.location.href = '<?php Helper::options()->adminUrl('options-theme.php'); ?>'
                </script>
            <?php }
        }
    }
    if ($_POST["type"] == "Khôi phục cài đặt") {
        if ($db->fetchRow($db->select()->from('table.options')->where('name = ?', 'theme:' . $name . '_backup'))) {
            $_value = $db->fetchRow($db->select()->from('table.options')->where('name = ?', 'theme:' . $name . '_backup'))['value'];
            $db->query($db->update('table.options')->rows(array('value' => $_value))->where('name = ?', 'theme:' . $name)); ?>
            <script>
                alert("Đã khôi phục thành công!");
                window.location.href = '<?php Helper::options()->adminUrl('options-theme.php'); ?>'
            </script>
        <?php } else { ?>
            <script>
                alert("Dữ liệu chưa được sao lưu và không thể khôi phục!");
                window.location.href = '<?php Helper::options()->adminUrl('options-theme.php'); ?>'
            </script>
        <?php } ?>
    <?php } ?>
    <?php if ($_POST["type"] == "Xóa bản sao lưu") {
        if ($db->fetchRow($db->select()->from('table.options')->where('name = ?', 'theme:' . $name . '_backup'))) {
            $db->query($db->delete('table.options')->where('name = ?', 'theme:' . $name . '_backup')); ?>
            <script>
                alert("Xóa thành công!");
                window.location.href = '<?php Helper::options()->adminUrl('options-theme.php'); ?>'
            </script>
        <?php } else { ?>
            <script>
                alert("Không có nội dung sao lưu và không thể xóa!");
                window.location.href = '<?php Helper::options()->adminUrl('options-theme.php'); ?>'
            </script>
        <?php } ?>
    <?php } ?>
<?php } ?>
<?php
echo '
    <form class="backup" action="?Joe_backup" method="post">
        <input type="submit" name="type" value="Sao lưu cài đặt" />
        <input type="submit" name="type" value="Khôi phục cài đặt" />
        <input type="submit" name="type" value="Xóa bản sao lưu" />
    </form>';
