<?php

/* 加强后台编辑器功能 */
if (Helper::options()->JEditor !== 'off') {
    Typecho_Plugin::factory('admin/write-post.php')->richEditor  = array('Editor', 'Edit');
    Typecho_Plugin::factory('admin/write-page.php')->richEditor  = array('Editor', 'Edit');
}

class Editor
{
    public static function Edit()
    {
?>
        <link rel="stylesheet" href="https://fastly.jsdelivr.net/npm/aplayer@1.10.1/dist/APlayer.min.css">
        <link rel="stylesheet" href="https://fastly.jsdelivr.net/npm/prism-theme-one-light-dark@1.0.4/prism-onedark.min.css">
        <link rel="stylesheet" href="<?php Helper::options()->themeUrl('typecho/write/css/joe.write.min.css') ?>">
        <script>
            window.JoeConfig = {
                uploadAPI: '<?php Helper::security()->index('/action/upload'); ?>',
                emojiAPI: '<?php Helper::options()->themeUrl('typecho/write/json/emoji.json') ?>',
                expressionAPI: '<?php Helper::options()->themeUrl('typecho/write/json/expression.json') ?>',
                characterAPI: '<?php Helper::options()->themeUrl('typecho/write/json/character.json') ?>',
                playerAPI: '<?php Helper::options()->JCustomPlayer ? Helper::options()->JCustomPlayer() : Helper::options()->themeUrl('library/player.php?url=') ?>',
                autoSave: <?php Helper::options()->autoSave(); ?>,
                themeURL: '<?php Helper::options()->themeUrl(); ?>',
                canPreview: false
            }
        </script>
        <script src="https://fastly.jsdelivr.net/npm/aplayer@1.10.1/dist/APlayer.min.js"></script>
        <script src="https://fastly.jsdelivr.net/npm/typecho-joe-next@6.2.4/plugin/prism/prism.min.js"></script>
        <script src="<?php Helper::options()->themeUrl('typecho/write/parse/parse.min.js') ?>"></script>
        <script src="<?php Helper::options()->themeUrl('typecho/write/dist/index.bundle.js') ?>"></script>
        <script src="<?php Helper::options()->themeUrl('assets/js/ying.short.js') ?>"></script>
<?php
    }
}
