<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
$theurl=Helper::options()->themeUrl.'/';
define("theurl",$theurl);

/* Tập tin lõi của Ying */
require_once("core/core.php");
require_once("core/Ying.php");

function themeConfig($form)
{
    $themeUrl = Ying::Theme_url();
    $options = Helper::options();

    $_db = Typecho_Db::get();
    $_prefix = $_db->getPrefix();
    try {
        if (!array_key_exists('views', $_db->fetchRow($_db->select()->from('table.contents')->page(1, 1)))) {
            $_db->query('ALTER TABLE `' . $_prefix . 'contents` ADD `views` INT DEFAULT 0;');
        }
        if (!array_key_exists('agree', $_db->fetchRow($_db->select()->from('table.contents')->page(1, 1)))) {
            $_db->query('ALTER TABLE `' . $_prefix . 'contents` ADD `agree` INT DEFAULT 0;');
        }
    } catch (Exception $e) {
    }
?>
    <link rel="stylesheet" href="<?php Helper::options()->themeUrl('typecho/config/css/config.min.css') ?>">
    <script src="<?php Helper::options()->themeUrl('typecho/config/js/config.min.js') ?>"></script>
    <div class="ying_config">
        <div>
            <div class="ying_config__aside">
                <div class="logo">YING</div>
                <ul class="tabs">
                    <li class="item" data-current="ying_notice">Thông báo</li>
                    <li class="item" data-current="ying_global">Cài đặt chung</li>
                    <li class="item" data-current="ying_image">Hình ảnh</li>
                    <li class="item" data-current="ying_post">Bài viết</li>
                    <li class="item" data-current="ying_aside">Thanh bên</li>
                    <li class="item" data-current="ying_index">Trang chủ</li>
                    <li class="item" data-current="ying_foot">Chân trang</li>
                    <li class="item" data-current="ying_other">Khác</li>
                </ul>
                <?php require_once('core/backup.php'); ?>
            </div>
        </div>
        <div class="ying_config__notice">Đang tải dữ liệu...</div>
    <?php
    $favicon = new Typecho_Widget_Helper_Form_Element_Text(
        'favicon',
        NULL,
        $options->themeUrl("/img/favicon.svg","Ying"),
        _t('Favicon'),
        _t('Giới thiệu: Dùng để đặt Favicon cho website, một Favicon tốt có thể mang lại cho người dùng giao diện rất chuyên nghiệp<br />
         Định dạng: URL hình ảnh hoặc địa chỉ Base64 <br />
         Khác: Tạo Favicon miễn phí <a target="_blank" href="//tool.lu/favicon">tool.lu/favicon</a>')
     );      
    $favicon->setAttribute('class', 'ying_content ying_image');
    $form->addInput($favicon);

    $logo = new Typecho_Widget_Helper_Form_Element_Text(
        'logo',
        NULL,
        NULL,
        _t('Logo website'),
        _t('Giới thiệu: Dùng để đặt logo cho website, một logo tốt có thể mang lại lượng truy cập hiệu quả cho website <br />
         Định dạng: URL hình ảnh hoặc địa chỉ Base64 <br />
         Khác: Tạo logo miễn phí <a target="_blank" href="//www.uugai.com">www.uugai.com</a>')
     );      
    $logo->setAttribute('class', 'ying_content ying_image');
    $form->addInput($logo);

    $coverimg = new Typecho_Widget_Helper_Form_Element_Text(
        'coverimg',
        NULL,
        $options->themeUrl("/img/default-bg.jpg","Ying"),
        'Ảnh bìa bài viết mặc định',
        'Nếu bạn không điền ảnh bìa bài viết khi viết bài thì ảnh này sẽ hiển thị.<br />
         Định dạng: địa chỉ hình ảnh.'
    );
    $coverimg->setAttribute('class', 'ying_content ying_image');
    $form->addInput($coverimg);

    $lazyimg = new Typecho_Widget_Helper_Form_Element_Text(
        'lazyimg',
        NULL,
        $options->themeUrl("/img/loading.gif","Ying"),
        'Ảnh Lazyload',
        _t('Giới thiệu: Được sử dụng để sửa đổi hình ảnh tải chậm mặc định của chủ đề'));
    $lazyimg->setAttribute('class', 'ying_content ying_image');
    $form->addInput($lazyimg);

    $diycss = new Typecho_Widget_Helper_Form_Element_Textarea(
        'diycss',
        NULL,
        NULL,
        'CSS tùy chỉnh (tùy chọn)',
        'Giới thiệu: Vui lòng điền nội dung CSS tùy chỉnh và không cần điền thẻ style.<br />
         Ví dụ: <b>body { --theme: #ff6800; --background: rgba(255,255,255,0.85) }</b>'
    );
    $diycss->setAttribute('class', 'ying_content ying_global');
    $form->addInput($diycss);

    $diyjs = new Typecho_Widget_Helper_Form_Element_Textarea(
        'diyjs',
        NULL,
        NULL,
        'JS tùy chỉnh (tùy chọn)',
        'Giới thiệu: Vui lòng điền nội dung JS tùy chỉnh, chẳng hạn như thống kê trang web, v.v. Không cần điền thẻ script khi điền.'
    );
    $diyjs->setAttribute('class', 'ying_content ying_global');
    $form->addInput($diyjs);

    $tongji = new Typecho_Widget_Helper_Form_Element_Textarea(
        'tongji',
        NULL,
        NULL,
        'Tùy chỉnh và thêm nội dung trong &lt;head&gt;&lt;/head&gt; (tùy chọn)',
        'Giới thiệu: Điều này được sử dụng để thêm nội dung tùy chỉnh trong thẻ &lt;head&gt;&lt;/head&gt;<br />
         Ví dụ: bạn có thể thêm css, js của bên thứ ba, v.v.'
    );
    $tongji->setAttribute('class', 'ying_content ying_global');
    $form->addInput($tongji);

    $facebook = new Typecho_Widget_Helper_Form_Element_Text(
        'facebook',
        NULL,
        NULL,
        'Facebook',
        'Giới thiệu: Dùng để hiển thị link Facebook ở chân trang, trang con,...'
    );
    $facebook->setAttribute('class', 'ying_content ying_aside');
    $form->addInput($facebook);
    $telegram = new Typecho_Widget_Helper_Form_Element_Text(
        'telegram',
        NULL,
        NULL,
        'Telegram',
        'Giới thiệu: Dùng để hiển thị link Telegram ở chân trang, trang con,...'
    );
    $telegram->setAttribute('class', 'ying_content ying_aside');
    $form->addInput($telegram);
    $github = new Typecho_Widget_Helper_Form_Element_Text(
        'github',
        NULL,
        NULL,
        'Github',
        'Giới thiệu: Dùng để hiển thị link Github ở chân trang, trang con,...'
    );
    $github->setAttribute('class', 'ying_content ying_aside');
    $form->addInput($github);
    /* --------------------------------------- */
    $avatar = new Typecho_Widget_Helper_Form_Element_Text(
        'avatar',
        NULL,
        $options->themeUrl("/img/no-avatar.png","Ying"),
        'Ảnh đại diện - PC/WAP',
        'Giới thiệu: Dùng để chỉnh sửa ảnh đại diện của blogger<br />
         Lưu ý: Nếu không điền, hình đại diện trong *cài đặt cá nhân* sẽ được hiển thị'
    );
    $avatar->setAttribute('class', 'ying_content ying_aside');
    $form->addInput($avatar);
    /* --------------------------------------- */
    $sidebg = new Typecho_Widget_Helper_Form_Element_Text(
        'sidebg',
        NULL,
        $options->themeUrl("/img/default-bg.jpg","Ying"),
        'Ảnh bìa - PC',
        'Giới thiệu: Dùng để chỉnh sửa ảnh bìa <br/>
         Định dạng: địa chỉ hình ảnh hoặc địa chỉ Base64'
    );
    $sidebg->setAttribute('class', 'ying_content ying_aside');
    $form->addInput($sidebg);
    $status = new Typecho_Widget_Helper_Form_Element_Textarea(
        'status',
        NULL,
        NULL,
        'Tâm trạng/châm ngôn',
        'Giới thiệu: tâm trạng hoặc châm ngôn này sẽ xuất hiện ở dưới avatar, nếu không điền nó sẽ bị bỏ trống.'
    );
    $status->setAttribute('class', 'ying_content ying_aside');
    $form->addInput($status);
    /* --------------------------------------- */
    $typed_text = new Typecho_Widget_Helper_Form_Element_Textarea(
        'typed_text',
        NULL,
        'Thế giới này quá dỗi tàn nhẫn, nhưng dù vậy... Anh vẫn vẹn toàn yêu em! ',
        'Châm ngôn chân trang',
        'Giới thiệu: 1 dòng/1 châm ngôn.'
    );
    $typed_text->setAttribute('class', 'ying_content ying_foot');
    $form->addInput($typed_text);

    $navLinks = new Typecho_Widget_Helper_Form_Element_Textarea(
        'navLinks',
        NULL,
        'All4vn $ https://all4vn.cf $ https://all4vn.cf/yunying.jpg $ All4vn - Yakito
All4vn $ https://all4vn.cf $ https://all4vn.cf/yunying.jpg $ All4vn - Yakito',
        'Liên kết thanh bên',
        'Giới thiệu: 1 dòng/1 liên kết <br/>
         Ví dụ: Tên hiển thị $ URL $ Biểu tượng (Logo) $ Mô tả<br />
            <b>All4vn $ https://all4vn.cf $ https://all4vn.cf/yunying.jpg $ All4vn - Yakito</b>'
    );
    $navLinks->setAttribute('class', 'ying_content ying_aside');
    $form->addInput($navLinks);
    $footerLinks = new Typecho_Widget_Helper_Form_Element_Textarea(
        'footerLinks',
        NULL,
        'All4vn $ https://all4vn.cf
All4vn $ https://all4vn.cf',
        'Liên kết chân trang',
        'Giới thiệu: 1 dòng/1 liên kết <br/>
         Ví dụ: Tên hiển thị $ URL<br />
            <b>All4vn $ https://all4vn.cf</b>'
    );
    $footerLinks->setAttribute('class', 'ying_content ying_foot');
    $form->addInput($footerLinks);
    $CopyRight = new Typecho_Widget_Helper_Form_Element_Text(
        'CopyRight',
        NULL,
        'Copyright © 2022 by Yakito' ,
        'Bản quyền chân trang',
        'Giới thiệu: Dùng để đặt văn bản bản quyền ở chân trang.'
    );
    $CopyRight->setAttribute('class', 'ying_content ying_foot');
    $form->addInput($CopyRight);


    $compressHtml = new Typecho_Widget_Helper_Form_Element_Radio(
        'compressHtml',
        array('Off' => 'Tắt (mặc định)', 'On' => 'Bật'),
        'Off',
        'Nén HTML',
        'Tắt theo mặc định, bật nó sẽ nén mã HTML, có thể có vấn đề về tương thích với một số plug-in, vui lòng chọn bật hoặc tắt cho phù hợp'
    );
    $compressHtml->setAttribute('class', 'ying_content ying_other');
    $form->addInput($compressHtml->multiMode());

    $night = new Typecho_Widget_Helper_Form_Element_Radio(
        'night',
        array('Off' => 'Tắt (mặc định)', 'On' => 'Bật'),
        'Off',
        'Có tự động chuyển sang chế độ ban đêm hay không?',
        'Nó được bật theo mặc định và chế độ ban đêm sẽ tự động chuyển đổi vào lúc 8 giờ sáng và tối, sau khi bật chế độ ban đêm tự động, thời gian hiệu quả của việc điều chỉnh chế độ ban đêm theo cách thủ công là 8 giờ'
    );
    $night->setAttribute('class', 'ying_content ying_other');
    $form->addInput($night->multiMode());

    $reward = new Typecho_Widget_Helper_Form_Element_Radio(
        'reward',
        array('Off' => 'Tắt (mặc định)', 'On' => 'Bật'),
        'Off',
        'Có bật quyên góp hay không?',
        'Tắt theo mặc định'
    );
    $reward->setAttribute('class', 'ying_content ying_post');
    $form->addInput($reward);
    $thumbUp = new Typecho_Widget_Helper_Form_Element_Radio(
        'thumbUp',
        array('Off' => 'Tắt (mặc định)', 'On' => 'Bật'),
        'Off',
        'Có bật thích bài viết hay không?',
        'Tắt theo mặc định'
    );
    $thumbUp->setAttribute('class', 'ying_content ying_post');
    $form->addInput($thumbUp);
    $poster = new Typecho_Widget_Helper_Form_Element_Radio(
        'poster',
        array('Off' => 'Tắt (mặc định)', 'On' => 'Bật'),
        'Off',
        'Có bật tạo áp phích hay không?',
        'Tắt theo mặc định'
    );
    $poster->setAttribute('class', 'ying_content ying_post');
    $form->addInput($poster);
    $momo = new Typecho_Widget_Helper_Form_Element_Text(
        'momo',
        NULL,
        $options->themeUrl("/img/qr-momo.jpg","Ying"),
        'QR ví MoMo',
        'Giới thiệu: Nếu bật chức năng quyên góp thì vui lòng nhập link ảnh mã QR nhận tiền Ví MoMo ở đây.'
    );
    $momo->setAttribute('class', 'ying_content ying_post');
    $form->addInput($momo);
    $JEditor = new Typecho_Widget_Helper_Form_Element_Select(
        'JEditor',
        array(
            'on' => 'Đã bật (mặc định)',
            'off' => 'Tắt',
        ),
        'on',
        'Có bật trình chỉnh sửa tùy chỉnh Joe hay không?',
        'Giới thiệu: Sau khi mở, trình soạn thảo bài viết sẽ được thay thế bởi trình soạn thảo Joe <br>
         Khác: Trình chỉnh sửa hiện đang trong giai đoạn phát triển, nếu bạn muốn tiếp tục sử dụng trình chỉnh sửa gốc, chỉ cần tắt mục này.'
    );
    $JEditor->setAttribute('class', 'ying_content ying_post');
    $form->addInput($JEditor->multiMode());

    $JPrismTheme = new Typecho_Widget_Helper_Form_Element_Select(
        'JPrismTheme',
        array(
            'https://all4vn.cf/usr/themes/Ying/assets/css/HLstyle/default.min.css' => 'prism (mặc định)',
            '//fastly.jsdelivr.net/npm/prismjs@1.23.0/themes/prism-dark.min.css' => 'prism-dark',
            '//fastly.jsdelivr.net/npm/prismjs@1.23.0/themes/prism-okaidia.min.css' => 'prism-okaidia',
            '//fastly.jsdelivr.net/npm/prismjs@1.23.0/themes/prism-solarizedlight.min.css' => 'prism-solarizedlight',
            '//fastly.jsdelivr.net/npm/prismjs@1.23.0/themes/prism-tomorrow.min.css' => 'prism-tomorrow',
            '//fastly.jsdelivr.net/npm/prismjs@1.23.0/themes/prism-twilight.min.css' => 'prism-twilight',
            '//fastly.jsdelivr.net/npm/prism-themes@1.7.0/themes/prism-a11y-dark.min.css' => 'prism-a11y-dark',
            '//fastly.jsdelivr.net/npm/prism-themes@1.7.0/themes/prism-atom-dark.min.css' => 'prism-atom-dark',
            '//fastly.jsdelivr.net/npm/prism-themes@1.7.0/themes/prism-base16-ateliersulphurpool.light.min.css' => 'prism-base16-ateliersulphurpool.light',
            '//fastly.jsdelivr.net/npm/prism-themes@1.7.0/themes/prism-cb.min.css' => 'prism-cb',
            '//fastly.jsdelivr.net/npm/prism-themes@1.7.0/themes/prism-coldark-cold.min.css' => 'prism-coldark-cold',
            '//fastly.jsdelivr.net/npm/prism-themes@1.7.0/themes/prism-coldark-dark.min.css' => 'prism-coldark-dark',
            '//fastly.jsdelivr.net/npm/prism-themes@1.7.0/themes/prism-darcula.min.css' => 'prism-darcula',
            '//fastly.jsdelivr.net/npm/prism-themes@1.7.0/themes/prism-dracula.min.css' => 'prism-dracula',
            '//fastly.jsdelivr.net/npm/prism-themes@1.7.0/themes/prism-duotone-dark.min.css' => 'prism-duotone-dark',
            '//fastly.jsdelivr.net/npm/prism-themes@1.7.0/themes/prism-duotone-earth.min.css' => 'prism-duotone-earth',
            '//fastly.jsdelivr.net/npm/prism-themes@1.7.0/themes/prism-duotone-forest.min.css' => 'prism-duotone-forest',
            '//fastly.jsdelivr.net/npm/prism-themes@1.7.0/themes/prism-duotone-light.min.css' => 'prism-duotone-light',
            '//fastly.jsdelivr.net/npm/prism-themes@1.7.0/themes/prism-duotone-sea.min.css' => 'prism-duotone-sea',
            '//fastly.jsdelivr.net/npm/prism-themes@1.7.0/themes/prism-duotone-space.min.css' => 'prism-duotone-space',
            '//fastly.jsdelivr.net/npm/prism-themes@1.7.0/themes/prism-ghcolors.min.css' => 'prism-ghcolors',
            '//fastly.jsdelivr.net/npm/prism-themes@1.7.0/themes/prism-gruvbox-dark.min.css' => 'prism-gruvbox-dark',
            '//fastly.jsdelivr.net/npm/prism-themes@1.7.0/themes/prism-hopscotch.min.css' => 'prism-hopscotch',
            '//fastly.jsdelivr.net/npm/prism-themes@1.7.0/themes/prism-lucario.min.css' => 'prism-lucario',
            '//fastly.jsdelivr.net/npm/prism-themes@1.7.0/themes/prism-material-dark.min.css' => 'prism-material-dark',
            '//fastly.jsdelivr.net/npm/prism-themes@1.7.0/themes/prism-material-light.min.css' => 'prism-material-light',
            '//fastly.jsdelivr.net/npm/prism-themes@1.7.0/themes/prism-material-oceanic.min.css' => 'prism-material-oceanic',
            '//fastly.jsdelivr.net/npm/prism-themes@1.7.0/themes/prism-night-owl.min.css' => 'prism-night-owl',
            '//fastly.jsdelivr.net/npm/prism-themes@1.7.0/themes/prism-nord.min.css' => 'prism-nord',
            '//fastly.jsdelivr.net/npm/prism-themes@1.7.0/themes/prism-pojoaque.min.css' => 'prism-pojoaque',
            '//fastly.jsdelivr.net/npm/prism-themes@1.7.0/themes/prism-shades-of-purple.min.css' => 'prism-shades-of-purple',
            '//fastly.jsdelivr.net/npm/prism-themes@1.7.0/themes/prism-synthwave84.min.css' => 'prism-synthwave84',
            '//fastly.jsdelivr.net/npm/prism-themes@1.7.0/themes/prism-vs.min.css' => 'prism-vs',
            '//fastly.jsdelivr.net/npm/prism-themes@1.7.0/themes/prism-vsc-dark-plus.min.css' => 'prism-vsc-dark-plus',
            '//fastly.jsdelivr.net/npm/prism-themes@1.7.0/themes/prism-xonokai.min.css' => 'prism-xonokai',
            '//fastly.jsdelivr.net/npm/prism-theme-one-light-dark@1.0.4/prism-onelight.min.css' => 'prism-onelight',
            '//fastly.jsdelivr.net/npm/prism-theme-one-light-dark@1.0.4/prism-onedark.min.css' => 'prism-onedark',
            '//fastly.jsdelivr.net/npm/prism-theme-one-dark@1.0.0/prism-onedark.min.css' => 'prism-onedark2',
        ),
        'https://all4vn.cf/usr/themes/Ying/assets/css/HLstyle/default.min.css',
        'Chọn kiểu khối mã',
        'Giới thiệu: Làm nổi bật phong cách để sửa đổi các khối mã <br>
         Khác: Nếu bạn có các kiểu khác, bạn có thể sửa đổi kiểu này từ mã nguồn để đưa vào liên kết kiểu tùy chỉnh của mình'
    );
    $JPrismTheme->setAttribute('class', 'ying_content ying_post');
    $form->addInput($JPrismTheme);

    $index_layout = new Typecho_Widget_Helper_Form_Element_Radio('index_layout', array(
			'layout1'=>_t('Bên trái và bên phải'),
			'layout2'=>_t('Trên và dưới'),
		), 
			"layout1", _t('Vị trí băng chuyền ở trang chủ'), _t(''));
    $index_layout->setAttribute('class', 'ying_content ying_index');
    $form->addInput($index_layout->multiMode());

    $tagpage = new Typecho_Widget_Helper_Form_Element_Radio(
        'tagpage',
        array('page1' => 'Đơn giản', 'page2' => 'Đồ họa'),
        'off',
        'Kiểu hiển thị tagpage (ở dưới băng chuyền)',
        ''
    );
    $tagpage->setAttribute('class', 'ying_content ying_index');
    $form->addInput($tagpage);

    $banner_ctrl = new Typecho_Widget_Helper_Form_Element_Radio(
        'banner_ctrl',
        array('Off' => 'Tắt (mặc định)', 'On' => 'Bật'),
        'Off',
        'Có hiển thị băng chuyền bài viết trên trang chủ hay không?',
        'Nó tắt theo mặc định, nếu bật ảnh bìa bìa mặc định sẽ được hiển thị!'
    );
    $banner_ctrl->setAttribute('class', 'ying_content ying_index');
    $form->addInput($banner_ctrl);

    $duanju = new Typecho_Widget_Helper_Form_Element_Radio(
        'duanju',
        array('Off' => 'Tắt (mặc định)', 'On' => 'Bật'),
        'Off',
        'Có bật cụm từ ngẫu nhiên băng chuyền hay không?',
        'Nó mặc định là tắt, tích vào nghĩa là nó đang bật, còn nếu không bật thì nó sẽ hiển thị tiêu đề của trang web!<br>
         Lưu ý: Cụm từ nằm ở thư mục /assets/word.txt của chủ đề'
    );
    $duanju->setAttribute('class', 'ying_content ying_index');
    $form->addInput($duanju);

    $loadingStyle = new Typecho_Widget_Helper_Form_Element_Select('loadingStyle',array(
			'loading-1'=>'Kiểu 1',
			'loading-2'=>'Kiểu 2',
			'loading-3'=>'Kiểu 3',
			'loading-4'=>'Kiểu 4',
			'loading-5'=>'Kiểu 5',
			'loading-6'=>'Kiểu 6'),
			'loading-1','Phong cách hoạt ảnh tải trang');
    $loadingStyle->setAttribute('class', 'ying_content ying_index');
    $form->addInput($loadingStyle);	

    $sider_layout = new Typecho_Widget_Helper_Form_Element_Radio('sider_layout', array(
			'layout1'=>_t('Bên phải'),
			'layout2'=>_t('Bên trái'),
		), 
			"layout1", _t('Vị trí thanh bên'), _t(''));
    $sider_layout->setAttribute('class', 'ying_content ying_aside');
    $form->addInput($sider_layout);

    $sideWidget = new Typecho_Widget_Helper_Form_Element_Checkbox('sideWidget', 
	    array(
			'user-widget' => _t('Thông tin cá nhân'),
			'nav-links' => _t('Liên kết điều hướng'),
			'web-widget' => _t('Thống kê'),
			'new-comt' => _t('Bình luận mới'),
			'new-update' => _t('Cập nhật mới'),
			'tags-cloud' => _t('Tags Cloud'),
			),
    array('user-widget','tags-cloud'), _t('Mô-đun hiển thị thanh bên'), _t(''));
    $sideWidget->setAttribute('class', 'ying_content ying_aside');
    $form->addInput($sideWidget->multiMode());
    
    $JFriends = new Typecho_Widget_Helper_Form_Element_Textarea(
        'JFriends',
        NULL,
        'Hữu Phương || https://all4vn.cf || https://all4vn.cf/yunying.jpg || This World is CREUL but still... BEAUTIFUL!',
        'Liên kết trang nội bộ (tùy chọn)',
        'Giới thiệu: Dùng để điền kết bạn bè <br />
         Lưu ý: Bạn cần thêm trang liên kết bạn bè trước (thêm trang độc lập - chọn liên kết bạn bè mẫu bên phải) thì mục này mới có hiệu lực. <br />
         Định dạng: Tên blog || Địa chỉ blog || Ảnh đại diện blog || Mô tả blog <br />
         Khác: một trên mỗi dòng, một dòng đại diện cho một liên kết bạn bè'
    );
    $JFriends->setAttribute('class', 'ying_content ying_other');
    $form->addInput($JFriends);

	$footnew = new Typecho_Widget_Helper_Form_Element_Text(
	'footnew',
	NULL,
	NULL,
	_t('ID chuyên mục riêng'),
	_t('Nhập ID chuyên mục và bài viết mới nhất của chuyên mục được đề xuất sẽ được hiển thị ở dưới cùng, nếu nó không được điền, nó sẽ không được hiển thị'));
    $form->addInput($footnew);
    $footnew->setAttribute('class', 'ying_content ying_index');

    $tbon = new Typecho_Widget_Helper_Form_Element_Radio(
        'tbon',
        array('Off' => 'Tắt (mặc định)', 'On' => 'Bật'),
        'Off',
        'Có bật bảng thông báo hay không?',
        'Nó mặc định là tắt, tích vào nghĩa là nó đang bật, còn nếu không bật thì nó sẽ không hiển thị gì cả!'
    );
    $tbon->setAttribute('class', 'ying_content ying_index');
    $form->addInput($tbon);

    $tb = new Typecho_Widget_Helper_Form_Element_Textarea(
        'tb',
        NULL,
        'Chào mừng đến với <strong>All4vn</strong>!</p><p>Ồ! Cuối cùng bạn cũng đã đến! Thông báo này chỉ đơn giản là để nói lời cảm ơn! Hiện tại, chủ đề <strong>Ying</strong> còn đang trong quá trình phát triển nếu có lỗi hoặc vấn đề gì đó xin hãy nói cho mình biết, mình sẽ khắc phục!</p> <p>Bạn hãy thường xuyên ghé thăm <strong>All4vn</strong> để bạn không bao giờ bỏ lỡ bất kỳ bài viết hay nào!</p> <p>Thế giới này quá dỗi tàn nhẫn nhưng dù vậy... Anh vẫn vẹn toàn yêu em!',
        'Popup thông báo',
        'Giới thiệu: Dùng để bật bảng thông báo cho blog (hỗ trợ HTML), cách nhau 24h sẻ hiển thị 1 lần!<br />
         Lưu ý: Hãy bật chức năng thông báo nếu muốn hiển thị chức năng này. <br />'
    );
    $tb->setAttribute('class', 'ying_content ying_index');
    $form->addInput($tb);

    $mode = new Typecho_Widget_Helper_Form_Element_Radio('mode', array(
        1 => _t('Album'),
        ), 1, _t('Chế độ bài viết Album ảnh'), _t('Mặc định, không được tắt!'));
        $mode->setAttribute('class', 'ying_content ying_post');
	$form->addInput($mode);

// Công tắc thông tin xã hội của thanh bên
$SocialSwitch = new Typecho_Widget_Helper_Form_Element_Select(
    'SocialSwitch',
    array(
        'off' => 'Tắt (mặc định)',
        'on' => 'Bật thông tin xã hội PC',
        'on1' => 'Mở thông tin xã hội PE',
        'on2' => 'Đồng thời mở thông tin xã hội PC và PE',
    ),
    'off',
    'Có bật thông tin xã hội của thanh bên hay không',
    'Giới thiệu: Sau khi bật, chức năng thông tin xã hội sẽ được hiển thị ở thanh bên (thông tin xã hội ở thanh bên dưới phải được điền vào)'
);
$SocialSwitch->setAttribute('class', 'ying_content ying_aside'); //Thay đổi joe_custom thành joe_other mà không cần custom.php
$form->addInput($SocialSwitch->multiMode());

//Thanh bên Thông tin xã hội
$SocialInfo = new Typecho_Widget_Helper_Form_Element_Textarea(
    'SocialInfo',
    NULL,
    NULL,
    'Thanh bên Thông tin xã hội',
    'Giới thiệu: Được sử dụng để đặt thông tin xã hội bên <br />
         Định dạng: ID QQ || URL mã QR WeChat của bạn || ID trạm B || ID Weibo<br />
         Ví dụ: 123456 || https://www.a.con/a.png || 13503064 || 3125196513 '
);
$SocialInfo->setAttribute('class', 'ying_content ying_aside');
$form->addInput($SocialInfo);

}

// Từ khóa tùy chỉnh
if($_SERVER['SCRIPT_NAME']=="/admin/write-post.php"){
	function themeFields($layout) {
        $slide = new Typecho_Widget_Helper_Form_Element_Radio('slide', 
		array('Yes' => _t('Có'),
		'No' => _t('Không')),'No' 
		,_t('Thêm vào Slides'),_t('Sau khi mở, bài viết sẽ được thêm vào băng chuyền trang chủ'));
		$layout->addItem($slide);
		
		$topPost = new Typecho_Widget_Helper_Form_Element_Radio('topPost', 
		array('Yes' => _t('Có'),
		'No' => _t('Không')),'No' 
		,_t('Ghim bài viết'),_t(''));
		$layout->addItem($topPost);

        $stylelist = new Typecho_Widget_Helper_Form_Element_Radio('stylelist',
        array('ying' => _t('Mặc định'),
              'new' => _t('Mới'),
		      'more' => _t('Video (chưa làm)'),
        ),
        'ying', _t('Kiểu bài viết'), _t('Chọn kiểu bài viết hiển thị ra trang chủ, hãy chọn để trang web được phong phú hơn!'));
        $layout->addItem($stylelist);

		$cover = new Typecho_Widget_Helper_Form_Element_Text('cover', NULL, NULL, _t('Bìa bài viết'), _t('Vui lòng điền địa chỉ của ảnh bìa, nếu bạn không nhập, ảnh bìa mặc định sẽ được sử dụng.'));
		$cover->input->setAttribute('class', 'w-100');
		$layout->addItem($cover);
		
		$keyword = new Typecho_Widget_Helper_Form_Element_Text('keyword', NULL, NULL, _t('Từ khóa'), _t('Vui lòng tách nhiều từ khóa bằng dấu phẩy'));
		$keyword->input->setAttribute('class', 'w-100');
		$layout->addItem($keyword);  
		
		$description = new Typecho_Widget_Helper_Form_Element_Textarea('description', NULL, NULL, _t('Mô tả'), _t('Nên điền vào ô này , vì nếu không điền thì mô tả bài viết ở trang chủ sẻ hiển thị BBCode (nếu có)'));
		$description->input->setAttribute('style', 'width:100%;height:120px;');
		$layout->addItem($description); 
	}


	}	

	if($_SERVER['SCRIPT_NAME']=="/admin/write-page.php"){
		function themeFields($layout) {
			$cover = new Typecho_Widget_Helper_Form_Element_Text('cover', NULL, NULL, _t('Ảnh bìa'), _t('Vui lòng điền địa chỉ của ảnh bìa, nếu bạn không nhập, ảnh bìa mặc định sẽ được sử dụng'));
			$cover->input->setAttribute('class', 'w-100');
			$layout->addItem($cover);
			
			$icon = new Typecho_Widget_Helper_Form_Element_Text('icon', NULL, NULL, _t('Biểu tượng trang'), _t('Sử dụng icon của Ying, mình sẽ update trang lấy icon sau!'));
			$icon->input->setAttribute('class', 'w-100');
			$layout->addItem($icon);  
		}
	}	