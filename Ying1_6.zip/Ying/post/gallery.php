<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit;
$imgs = getPostHtmImg($this);
if($this->fields->postType == 1||!isset($imgs)){
$this->need('page.php');
}else{
?>
<div class="gallery-post">
<div class="gallery-page wd-100">
	<?php $this->need('component/posthead.php'); ?>
	<ul class="gallery-list flex-wrap">

<?php 
foreach($imgs as $img) {
$imgurl=$img['url'];
$size='';

if($this->options->mode==1){

echo '<li class="gallery-item">
			<div class="g-img cursor" data-src="'.$imgurl.'" data-fancybox="gallery">
				<img class="wh-100 lazy transform" data-original="'.$imgurl.'" src="'.theurl.'img/loading.gif">
			</div>
		</li>';


}else{

echo '<div class="mdui-col-xs-6 mdui-col-md-3 mdui-col-lg-2 mb-1 ze-col"><div class="media '.$size.' p-0"><a data-fancybox="gallery" href="'.$imgurl.'" class="media-content scrollLoading item mdui-shadow-'.$this->options->shadow.' mdui-img-rounded" data-xurl="'.$img['url'].'" title="'.$img['title'].'" data-caption="'.$img['title'].'" data-thumb="'.$img['url'].'"></a></div></div>';
}
}
?>

	</ul>
</div>
<div class="comment-box"><?php $this->need('comments.php');} ?></div>
</div>
    <?php if ($this->options->sider_layout == "layout1" && $this->options->sideWidget) {$this->need('./includes/sidebar.php');} ?>
