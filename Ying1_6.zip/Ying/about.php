<?php 
/**
 * About
 * @package custom 
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;
$this->need('includes/header.php');
?>

<?php Typecho_Widget::widget('Widget_Stat')->to($stat); ?>
<div class="col-mb-12 col-8" id="main" role="main">
<div class="archive-bg">
        <div class="diy-archive-bg wh-100" style="background-image: url(<?php if($this->fields->cover){echo $this->fields->cover;}else{echo $this->options->coverimg;} ?>);">
            <div class="about-page-name">
                    <?php $this->title(); ?>
            </div> 
            <span class="default-cover"><?php echo $this->options->coverimg ?></span>
            <div class="aner"></div>
        </div>
</div>
<div class="layout-page">
    <div class="page">
    <article  class="page-post ab-article" itemscope itemtype="http://schema.org/BlogPosting">
        <div class="about-row">
            <div class="ab-side hide7">
                <div class="xcenter">
                    <ul class="user-info">
                    <li><span class="user-tags c-blue hint--top" aria-label="Có <?php $stat->publishedPostsNum() ?> bài viết">
                        <i class="fa fa-file-text-o x5" aria-hidden="true"></i><?php $stat->publishedPostsNum() ?>
                    </span></li>
                    <li><span class="user-tags c-yellow hint--top" aria-label="Có <?php $stat->publishedCommentsNum() ?> lượt bình luận">
                        <i class="fa fa-commenting-o x5" aria-hidden="true"></i><?php $stat->publishedCommentsNum() ?></i>
                    </span></li>
                    <li><span class="user-tags c-green hint--top" aria-label="<?php $stat->categoriesNum() ?>chuyên mục">
                        <i class="fa fa-bar-chart x5" aria-hidden="true"></i> <?php $stat->categoriesNum() ?></i>
                    </span></li>
                    <li><span class="user-tags c-red hint--top" aria-label="Tổng số từ của trang web: <?php allOfCharacters(); ?>">
                        <i class="fa fa-file-word-o x5" aria-hidden="true"></i><?php allOfCharacters(); ?></i>
                    </span></li>
                    </ul>
                </div>
            </div>
            <div class="ab-center">
                <div class="ab-avatar-box">
                    <img class="ab-avatar xcenter" src="<?php echo $this->options->avatar?>"  alt="About">
                </div>
                <div class="ab-name">
                    <h2 class="xcenter"><?php $this->options->title() ?></h2>
                    
                </div>
            </div>
            <div class="ab-side hide7">
                <div class="xcenter">
                    <ul class="ab-link">
                    <li class="ab-item qq cursor hint--top hint--rounded" aria-label="Facebook: <?php echo $this->options->facebook ?>"><i class="fa fa-facebook" aria-hidden="true"></i></li>
                    <li class="ab-item weixin cursor hint--top hint--rounded" aria-label="Telegram: <?php echo $this->options->telegram ?>"><i class="fa fa-telegram" aria-hidden="true"></i></li>
                    <li class="ab-item github cursor hint--top hint--rounded" aria-label="Github<?php echo $this->user->mail ?>"><i class="fa fa-github" aria-hidden="true"></i></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="ab-desc"><span class="xcenter"><?php $this->options->description() ?></span></div>
        <div class="ab-show7">
            <div class="ab7">
                <div class="xcenter">
                    <ul class="user-info">
                    <li><span class="user-tags c-blue hint--top" aria-label="Đã đăng <?php $stat->publishedPostsNum() ?> bài viết">
                        <i class="fa fa-file-text-o x5" aria-hidden="true"></i><?php $stat->publishedPostsNum() ?>
                    </span></li>
                    <li><span class="user-tags c-yellow hint--top" aria-label="<?php $stat->publishedCommentsNum() ?> lượt bình luận">
                        <i class="fa fa-commenting-o x5" aria-hidden="true"></i><?php $stat->publishedCommentsNum() ?></i>
                    </span></li>
                    <li><span class="user-tags c-green hint--top" aria-label="<?php $stat->categoriesNum() ?> chuyên mục">
                        <i class="fa fa-bar-chart x5" aria-hidden="true"></i> <?php $stat->categoriesNum() ?></i>
                    </span></li>
                    <li><span class="user-tags c-red hint--top" aria-label="Tổng số từ của trang web:<?php allOfCharacters(); ?>">
                        <i class="fa fa-file-word-o x5" aria-hidden="true"></i><?php allOfCharacters(); ?></i>
                    </span></li>
                    </ul>
                </div>
            </div>

            <div class="ab7">
                <div class="xcenter">
                    <ul class="ab-link">
                    <li class="ab-item qq cursor hint--top hint--rounded" aria-label="Facebook: <?php echo $this->options->facebook ?>"><i class="fa fa-facebook" aria-hidden="true"></i></li>
                    <li class="ab-item weixin cursor hint--top hint--rounded" aria-label="Telegram: <?php echo $this->options->telegram ?>"><i class="fa fa-telegram" aria-hidden="true"></i></li>
                    <li class="ab-item github cursor hint--top hint--rounded" aria-label="Github: <?php echo $this->user->github ?>"><i class="fa fa-github" aria-hidden="true"></i></li>
                    </ul>
                </div>
            </div>                
        </div>
        <div class="ab-post">
        <div id="page-post" class="aboutp post-content" itemprop="articleBody">
        <?php echo parseBiaoQing($this->content); ; ?>

        </div>
        </div>
    </article>
    <div class="comment-box cts">
     <?php $this->need('comments.php'); ?>
    </div>
    </div>
    </div>
</div>

<?php $this->need('./includes/footer.php'); ?>