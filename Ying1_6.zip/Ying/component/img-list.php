<br />
<div class="home-row-left content-area ">
    <style>
        .post-item-wzxw ul.b2_gap > li {
            width: 25%
        }
        
        .post-item-wzxw .item-in .post-info h2 {
            -webkit-line-clamp: 1;
        }
        
        @media screen and (max-width: 768px) {
            .post-item-wzxw .item-in .post-info h2 {
                -webkit-line-clamp: 2;
            }
        }
    </style>
<div id="post-item-wzxw" data-key="wzxw" class="post-1 post-list post-item-wzxw">
<div class="widget_text zib-widget widget_custom_html">
    <div class="textwidget custom-html-widget">
        <div class="box-body notop">
            <div class="title-theme"><?php echo catename($this->options->footnew); ?>
                <div class="pull-right em09 mt3"><a href="/category/gallery" class="muted-2-color"><i class="fa fa-angle-right fa-fw"></i> Xem thêm</a>
                </div>
            </div>
        </div>
    </div>
</div>
        <div class="hidden-line">
            <ul class="b2_gap">

                <?php $this->widget('Widget_Archive@category-' . $categories->mid, 'pageSize=7&type=category', 'mid='.$this->options->footnew.'')->to($posts); ?>
                <?php while($posts->next()): ?>
                <li id="item-<?php $this->cid(); ?>" class="post-list-item item-post-style-1">
                    <div class="item-in box b2-radius">
                        <div class="post-module-thumb" style="padding-top: 133.333%;">
                            <a href="<?php $posts->permalink(); ?>" rel="nofollow" class="thumb-link">
                                <picture class="picture">
                                    <source type="image/webp" data-srcset="<?php echo stcdnimg($posts->fields->cover); ?>" srcset="<?php echo stcdnimg($posts->fields->cover); ?>"><img data-src="<?php echo stcdnimg($posts->fields->cover); ?>" alt="<?php $this->title(); ?>" src="<?php echo stcdnimg($posts->fields->cover); ?>" class="post-thumb lazy entered loaded" data-ll-status="loaded">
                                </picture>
                            </a>
                        </div>
                        <div class="post-info">
                            <h2><a style="color: var(--font-color1);" href="<?php $posts->permalink(); ?>"><?php $posts->title(); ?></a></h2>
                            <div class="post-excerpt">
                                <?php echo stcdnimg($posts->fields->description); ?>
                            </div>
                            <div class="post-list-meta-box">
                                <div class="post-list-cat  b2-radius"><a href="/category/gallery" class="post-list-cat-item b2-radius" style="color: rgb(96, 125, 139);"><i class="fa fa-folder"></i> <?php echo catename($this->options->footnew); ?></a>
                                </div>
                                <ul class="post-list-meta">
                                    <li class="post-list-meta-views"><span><i class="fa fa-comment-o"></i>&nbsp;<?php $posts->commentsNum(); ?></span>
                                    </li> 
                                    <li class="post-list-meta-views"><span><i class="fa fa-eye"></i>&nbsp;<?php Postview($posts); ?></span>
                                    </li>
                                </ul>
                            </div>
                            <div class="list-footer">
                                <a href="#" class="post-list-meta-avatar">
                                    <picture class="picture">
                                        <source type="image/webp" data-srcset="<?php $this->options->avatar() ?>" srcset="<?php $this->options->avatar() ?>"><img data-src="<?php $this->options->avatar() ?>" alt="Yakito" src="<?php $this->options->avatar() ?>" class="avatar b2-radius lazy entered loaded" data-ll-status="loaded">
                                    </picture><span><?php $this->author();?></span>
                                </a><span><time datetime="<?php echo "". time_diff(getUpdateTime($this->cid)); ?>" itemprop="datePublished" timeago-id="9" class="b2timeago"><i class="fa fa-clock-o"></i>&nbsp;<?php echo "". time_diff(getUpdateTime($this->cid)); ?></time></span>
                            </div>
                        </div>
                    </div>
                </li>
                <?php endwhile; ?>
            </ul>
        </div>
    </div>
</div>