<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<section id="rightside" style="opacity: 1; transform: translateX(-38px);">
  <div id="r-show" >
    <a class="cursor toggle-theme"><i class="sw-btn fa <?php if(strlen($_COOKIE['night']) !== 0){if($_COOKIE["night"]=="1"){echo "fa-sun-o";}else{echo "fa-moon-o";}}else{if($this->options->night == "On"){if(Switch_day()){echo "fa-sun-o";}else{echo "fa-moon-o";}}else{echo "fa-moon-o";}}?> ycenter" aria-hidden="true"></i></a>

    <?php $admin = get_object_vars($this->user)['row']['group']; if ($admin == "administrator") :?>
    <a id="piccolor" class="cursor md-trigger" data-modal="colorSet"><svg class="ying ycenter" aria-hidden="true"><use xlink:href="#ying-zhuangxiu"></use></svg></a>
    <?php endif; ?>

    <?php $admin = get_object_vars($this->user)['row']['group']; if ($admin == "administrator" && $this->is('post')) :?>
      <a id="postedit" class="cursor md-trigger" data-modal="edit-post"><svg class="ying ycenter" aria-hidden="true"><use xlink:href="#ying-bianji"></use></svg></a>
    <?php endif; ?>

    <?php if($this->is('post') && $this->category !== 'gallery' && $this->category !== 'video') :?>
    <a id="toc-btn" class="cursor"><svg class="ying ycenter" aria-hidden="true"><use xlink:href="#ying-liebiao"></use></svg></a>
    <a id="m-toc-btn" class="cursor"><svg class="ying ycenter" aria-hidden="true"><use xlink:href="#ying-liebiao"></use></svg></i></a>
    <?php endif; ?>
  
    <?php $admin = get_object_vars($this->user)['row']['group']; if ($admin == "administrator" && $this->is('archive')) :?>
    <a class="cursor md-trigger" data-modal="arc-edit"><i class="fa fa-cogs ycenter" aria-hidden="true" ></i></a>
    <?php endif; ?>

    <?php $admin = get_object_vars($this->user)['row']['group']; if ($admin == "administrator" && $this->is('page')) :?>
    <a class="cursor md-trigger" data-modal="page-edit"><i class="fa fa-cogs ycenter" aria-hidden="true" ></i></a>
    <?php endif; ?>

    <?php $admin = get_object_vars($this->user)['row']['group']; if ($admin == "administrator" && ($this->template == 'links.php')) :?>
    <a class="cursor delete-link"><i class="fa fa-link ycenter" aria-hidden="true" ></i></a>
    <a class="cursor md-trigger" data-modal="add-link"><i class="fa fa-plus-square ycenter" aria-hidden="true" ></i></a>
    <?php endif; ?>

    <?php $admin = get_object_vars($this->user)['row']['group']; if ($admin == "administrator" && ($this->template == 'talks.php')) :?>
    <a class="cursor edit-talks"><i class="fa fa-pencil-square ycenter" aria-hidden="true" ></i></a>
    <a class="cursor md-trigger" data-modal="add-talk"><i class="fa fa-plus-square ycenter" aria-hidden="true" ></i></a>
    <?php endif; ?>



  </div>
  <div id="r-show">
    <a id="go-up" class="btn-hidden cursor" type="button" title="Trở lại đầu trang"><svg class="ying ycenter" aria-hidden="true"><use xlink:href="#ying-jiasu"></use></svg></a>
  </div>
</section>


<div class="md-modal md-effect-1 wd-100 top20" id="modal-search">
  <div class="md-content md-content-search xcenter1">
    <div class="md-close close-icon cursor"><i class="fa fa-times fa-1-3x" aria-hidden="true"></i></div> 
    <div class="search search-bar">
      <form id="top-search" class="wt-100" method="post" action="<?php $this->options->siteUrl(); ?>" role="search">
        <input type="text" id="s" class="search-input" name="s" class="text" placeholder="Vui lòng nhập từ khóa và nhấn Enter..." />
        <button class="search-btn cursor" type="submit"></button>
      </form>
    </div>
  </div>
</div>

<div class="md-modal md-effect-2" id="colorSet" aria-hidden="true">
  <div class="md-content md-content-arc">
      <div class="arc-edit-box xcenter">
      <div class="md-close close-icon cursor"><i class="fa fa-times " aria-hidden="true"></i></div> 
        <div class="arc-edit-head">
          <h3><i class="fa fa-sliders" aria-hidden="true"></i>&nbsp;Đặt màu chủ đề</h3>
        </div>
        <div class="arc-edit-body">
          <div  class="md-link-item piccolor xcenter"></div>
        </div>
        <div class="arc-edit-footer">
          <div class="option-sub">
            <div class="xcenter">
              <button id="color-btn" class="page-btn cursor" type="button" data-url="<?php $this->options->siteUrl(); ?>"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;Xác nhận</button>
            </div>
          </div>
        </div>
      </div>
  </div>
</div>

<?php if($this->is('post') && $this->options->reward == "On"): ?>
  <!-- Thành phần -->
<div class="md-modal md-effect-4" id="reward" aria-hidden="true">
	<div class="md-content md-content-reward">
		<div class="reward-box xcenter">   
			<div class="md-close close-icon cursor"><i class="fa fa-times " aria-hidden="true"></i></div>	
      <h3><i class="fa fa-heart" aria-hidden="true"></i>&nbsp;Bài viết hay, ủng hộ&nbsp;<i class="fa fa-heart" aria-hidden="true"></i></h3>
      <div class="reward-qrcode">
        <div class="xcenter">
          <img src="<?php $this->options->momo() ?>" alt="Quyên góp Ví MoMo">
        </div>
      </div>
		</div>
	</div>
</div>
<?php endif; ?>

<?php if($this->is('post')): ?>
<!-- Tạo áp phích -->
<div class="md-modal md-modal1" id="poster" aria-hidden="true">
  <div class="md-close close-icon cursor" style="display: none;"><i class="fa fa-times " aria-hidden="true"></i></div> 
	<div class="md-content md-content-poster xcenter1">
      <div id="create-poster" class="poster-box potsize wh-100">
        <div class="poster-img" style="object-fit: cover;">
          <div class="poster-date"><span><?php Weekday(); ?></span><span><?php echo date("d/m"); ?></span></div>
        </div>
        <div class="poster-info">
          <div class="poster-title"><span id="poster-title" class="h-1x ycenter"></span></div>
          <div class="poster-label"></div>
          <div class="poster-sum"><span></span></div>
        </div>
      </div>
	</div>
</div>
<?php endif; ?>

<?php $admin = get_object_vars($this->user)['row']['group']; if ($admin == "administrator" && $this->is('post')) :?>
<div class="md-modal md-effect-6" id="edit-post" aria-hidden="true">
  <div class="md-content md-content-arc">
      <div class="arc-edit-box xcenter">
        <div class="md-close close-icon cursor"><i class="fa fa-times " aria-hidden="true"></i></div> 
        <div class="arc-edit-head">
          <h3><i class="fa fa-sliders" aria-hidden="true"></i>&nbsp;Cài đặt bài viết</h3>
        </div>
        <div class="arc-edit-body">
          <div class="option">
              <div class="option-text">
                <label class="ycenter editlabel">Thêm Sildes:</label>
                <input class="radio_input" name="slide" type="radio" value="Yes" id="post-slide-1" <?php if($this->fields->slide == "Yes"){echo 'checked';} ?>>&nbsp;<label class="radio-label">Có</label>
                <input name="slide" type="radio" value="No" id="post-slide-0" <?php if($this->fields->slide == "No"){echo 'checked';} ?>>&nbsp;<label class="radio-label">Không</label>
              </div>
          </div>
          <div class="option">
              <div class="option-text">
                <label class="ycenter editlabel">Ghim:</label>
                <input class="radio_input" name="topPost" type="radio" value="Yes" id="post-top-1" <?php if($this->fields->topPost == "Yes"){echo 'checked';} ?>>&nbsp;<label class="radio-label">Có</label>
                <input name="topPost" type="radio" value="No" id="post-top-0" <?php if($this->fields->topPost == "No"){echo 'checked';} ?>>&nbsp;<label class="radio-label">Không</label>
              </div>
          </div>     
         <div class="option">
            <div class="option-text"><label class="ycenter editlabel">Tên bài viết:</label></div>
            <input id="post-name-value" class="option-value" name="post-name" type="text" value="<?php $this->title() ?>">
          </div>
          <div class="option">
            <div class="option-text"><label class="ycenter editlabel">Ảnh bìa:</label></div>
            <input id="post-cover-value" class="option-value" name="post-cover" type="text" value="<?php echo showCover($this) ?>" placeholder="Vui lòng nhập liên kết ảnh bìa bài viết...">
          </div>     
          <div class="option">
            <div class="option-text"><label class="ycenter editlabel">Từ khóa:</label></div>
            <input id="post-keywords-value" class="option-value" name="post-keywords" type="text" value="<?php echo $this->fields->keyword; ?>" placeholder="Nhiều từ khóa được phân tách bằng dấu phẩy...">
          </div>
        <div class="option">
                <div class="option-text"><label class="ycenter editlabel">Mô tả:</label></div>
                <textarea id="post-desc-value" class="option-value" style="height: 7rem;" name="post-desc" type="text" value="" placeholder="Vui lòng nhập mô tả bài viết..."><?php echo $this->fields->description; ?></textarea>
            </div>
        </div>
        <div class="arc-edit-footer">
          <div class="option-sub">
          <button id="post-btn" class="arc-btn xcenter cursor" type="button" data-url="<?php  $this->permalink(); ?>" data-cid="<?php  $this->cid(); ?>"><i class="fa fa-check" aria-hidden="true"></i>&nbsp;Lưu thay đổi</button>
          </div>
        </div>
      </div>
  </div>
</div>
<?php endif; ?>


<?php $admin = get_object_vars($this->user)['row']['group']; if ($admin == "administrator" && $this->is('archive')) :?>
<!-- Trình chỉnh sửa trang chuyên mục -->
<div class="md-modal md-effect-11" id="arc-edit" aria-hidden="true">
	<div class="md-content md-content-arc">
      <div class="arc-edit-box xcenter">
        <div class="md-close close-icon cursor"><i class="fa fa-times " aria-hidden="true"></i></div> 
        <div class="arc-edit-head">
          <h3><i class="fa fa-sliders" aria-hidden="true"></i>&nbsp;Cài đặt chuyên mục</h3>
        </div>
        <div class="arc-edit-body">
         <div class="option">
            <div class="option-text"><label class="ycenter">Tên chuyên mục:</label></div>
            <input id="arc-name-value" class="option-value" name="arc-name" type="text" value="<?php  echo $this->getPageRow()['name'] ?>">
          </div>
          <div class="option">
            <div class="option-text"><label class="ycenter">Ảnh bìa:</label></div>
            <input id="arc-cover-value" class="option-value" name="arc-cover" type="text" value="<?php if($this->getPageRow()['cover']){echo $this->getPageRow()['cover'];}else{echo $this->options->coverimg;} ?>">
          </div>
          <div class="option">
            <div class="option-text"><label class="ycenter">Biểu tượng:</label></div>
            <input id="arc-icon-value" class="option-value" name="arc-icon" type="text" value="<?php echo $this->getPageRow()['icon']; ?>" placeholder="Ví dụ: ying-tên icon">
          </div>
          <div class="option">
            <div class="option-text"><label class="ycenter">Mô tả:</label></div>
            <input id="arc-desc-value" class="option-value" name="arc-desc" type="text" value="<?php echo $this->getDescription(); ?>" placeholder="Vui lòng nhập mô tả chuyên mục">
          </div>
        </div>
        <div class="arc-edit-footer">
          <div class="option-sub">
          <button id="arc-btn" class="arc-btn xcenter cursor" type="button" data-url="<?php echo $this->getPageRow()['permalink']; ?>" data-mid="<?php echo $this->getPageRow()['mid']; ?>"><i class="fa fa-check" aria-hidden="true"></i>&nbsp;Lưu thay đổi</button>
          </div>
        </div>
        <a class="getawe" href="http://www.fontawesome.com.cn/faicons/" target="_blank">Đi để lấy biểu tượng</a>
      </div>
	</div>
</div>
<?php endif; ?>

 
<?php $admin = get_object_vars($this->user)['row']['group']; if ($admin == "administrator" && $this->is('page')) :?>
 <!-- Biên tập trang -->
<div class="md-modal md-effect-11" id="page-edit" aria-hidden="true">
	<div class="md-content md-content-arc">
      <div class="arc-edit-box xcenter">
      <div class="md-close close-icon cursor"><i class="fa fa-times " aria-hidden="true"></i></div> 
        <div class="arc-edit-head">
          <h3><i class="fa fa-sliders" aria-hidden="true"></i>&nbsp;Cài đặt trang</h3>
        </div>
        <div class="arc-edit-body">
        <div class="option">
            <div class="option-text"><label class="ycenter">Ảnh bìa:</label></div>
            <input id="page-cover-value" class="option-value" name="page-cover" type="text" value="<?php if($this->fields->cover){echo $this->fields->cover;}else{echo $this->options->coverimg;} ?>">
          </div>
          <div class="option">
            <div class="option-text"><label class="ycenter">Biểu tượng:</label></div>
            <input id="page-icon-value" class="option-value" name="page-icon" type="text" value="<?php echo $this->fields->icon; ?>" placeholder="Ví dụ: ying-tên icon">
          </div>
        </div>
        <div class="arc-edit-footer">
          <div class="option-sub">
          <button id="page-btn" class="page-btn xcenter cursor" type="button" data-url="<?php echo $this->permalink(); ?>" data-cid="<?php $this->cid(); ?>"><i class="fa fa-check" aria-hidden="true"></i>&nbsp;Lưu thay đổi</button>
          </div>
        </div>
      </div>
	</div>
</div>
<?php endif; ?>