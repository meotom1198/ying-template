<div id="toc-widget" class="toc-widget card-widget" style="display: none;">
    <div class="toc-card smooth-toc">	
        <div class="card-title"><i class="fa fa-list-ul" aria-hidden="true"></i>&nbsp;&nbsp;Nội dung chính</div>
        <?php getCatalog(); ?>
    </div>
</div>