<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>

<div class="m-toc-widget shdow scale">
	<div class="toc-card">	
        <div class="card-title"><i class="fa fa-list-ul" aria-hidden="true"></i>&nbsp;&nbsp;Nội dung chính</div>
        <?php getCatalog(); ?>
    </div>	
</div>