<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>

<?php if (in_array("nav-links", $this->options->sideWidget)) : ?>
	<div class="card-widget">
		<div class="card-title"><p class="mycard_title"><svg class="ying" aria-hidden="true"><use xlink:href="#ying-fujian"></use></svg> Liên kết</p><i class="qiuqiu"></i></div>
		<div class="card-ul">
			<ul style="padding: 2px;">
				<?php foreach (array_filter(explode(PHP_EOL, $this->options->navLinks)) as $navlink) : ?>
					<li class="navlink"><a href="<?php echo trim(explode("$",$navlink)[1]); ?>">
						<img src="<?php echo trim(explode("$",$navlink)[2]); ?>">
						<div class="nav-info">
							<h4><?php echo trim(explode("$",$navlink)[0]); ?></h4>
							<p class="nav-p"><?php echo trim(explode("$",$navlink)[3]); ?></p>
						</div>
                <?php endforeach; ?>				
			</ul>
		</div>
	</div>
<?php endif; ?>

<?php if (in_array("new-update", $this->options->sideWidget)) : ?>
	<div class="card-widget">
	<div class="card-title"><p class="mycard_title"><svg class="ying" aria-hidden="true"><use xlink:href="#ying-renwu"></use></svg> Cập nhật gần đây</p><i class="qiuqiu"></i></div>
		<div class="card-ul">
			<ul>
				<?php $recentUpdate = recentUpdate(6); ?>
				<?php if ($recentUpdate) : $i = 0; ?>
					<?php foreach ($recentUpdate as $updatetarr) : $cid = $updatetarr['cid'];
						$this->widget('Widget_Archive@sidenewupdate' . $cid, 'pageSize=1&type=post', 'cid=' . $cid)->to($sideupdat); ?><?php $i += 1; ?>
					<li class="side-update">
						<div class="update-post">
							<a class="wh-100" href="<?php $sideupdat->permalink(); ?>" style="background-image: url('<?php echo showCover($sideupdat); ?>')"></a>
						</div>
						<div class="newpost-content">
							<a class="h-2x" href="<?php $sideupdat->permalink(); ?>"><span class="h-2x htitle"><?php $sideupdat->title(); ?></span></a>
							<div class="newpost-time">
								<span><?php echo "" . time_diff(getUpdateTime($cid)); ?></php></span>
							</div>
						</div>
					</li>
				<?php endforeach; ?>
			<?php endif; ?>
			</ul>
		</div>
	</div>
<?php endif; ?>

<?php if (in_array("tags-cloud", $this->options->sideWidget)) : ?>
	<div class="card-widget">
	<div class="card-title"><p class="mycard_title"><svg class="ying" aria-hidden="true"><use xlink:href="#ying-biaoqian"></use></svg> Tags</p><i class="qiuqiu"></i></div>
		<div class="tag-menu">
			<?php $this->widget('Widget_Metas_Tag_Cloud', 'ignoreZeroCount=1&limit=30')->to($tags); ?>
			<?php if ($tags->have()) : ?>
				<?php while ($tags->next()) : ?>
					<a class="black" href="<?php $tags->permalink(); ?>" title="Có <?php $tags->count(); ?> bài viết trong thẻ này">
					<span class="tag-item" style="background:rgba(<?php echo (rand(150, 200)); ?>,<?php echo (rand(150, 255)); ?>,<?php echo (rand(150, 255)); ?>,.5)"><svg class="ying" aria-hidden="true"><use xlink:href="#ying-biaoqian1"></use></svg>&nbsp;<?php $tags->name(); ?>
					</span></a>
				<?php endwhile; ?>
			<?php else : ?>
				<span align="center">Chưa có thẻ nào</span>
			<?php endif; ?>
		</div>
	</div>
<?php endif; ?>

<?php Typecho_Widget::widget('Widget_Stat')->to($stat); ?>
<?php if (in_array("web-widget", $this->options->sideWidget)) : ?>
	<div class="card-widget">
		<div class="card-title"><p class="mycard_title"><svg class="ying" aria-hidden="true"><use xlink:href="#ying-xuanxiang"></use></svg> Thống kê chi tiết</p><i class="qiuqiu"></i></div>
		<div class="card-ul">
			<ul>
				<li><i class="fa fa-dot-circle-o" aria-hidden="true"></i>&nbsp; Bài viết:<span class="badge"><?php $stat->publishedPostsNum() ?> bài</span></li>
				<li><i class="fa fa-dot-circle-o" aria-hidden="true"></i>&nbsp;Bình luận:<span class="badge"><?php $stat->publishedCommentsNum() ?> lượt</span></li>								
				<li><i class="fa fa-dot-circle-o" aria-hidden="true"></i>&nbsp;Ngày hiện tại:<span class="badge"><?php echo date('D • d-m-Y', time()); ?></span></li>
			</ul>
		</div>
	</div>
<?php endif; ?>