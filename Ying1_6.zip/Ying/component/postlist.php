<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<link rel="stylesheet" href="<?php $this->options->themeUrl('assets/css/bootstrap.min.css'); ?>">
<?php if(!empty(getTopPost())): ?>
<div><span class="icard">Sticked Posts</span></div>
<ul class="toppost flex-wrap shadow">
<?php $topCidArr = getTopPost();for($i=0;$i<count($topCidArr);$i++): $this->widget('Widget_Archive@topPost'.$i, 'pageSize=1&type=post', 'cid='.$topCidArr[$i])->to($topPost);?>
    <li class="bxb">
        <a class="wh-100" href="<?php echo $topPost->permalink; ?>">
            <div class="wh-100 topcover">
                <img class="wh-100" src="<? echo showCover($topPost); ?>">
                <div class="toptag"><span><i class="fa x5 fa-star-o" aria-hidden="true"></i>TOP</span></div>
            </div>
            <div class="toppost-info">
                <div class="toppost-title"><span class="h-1x"><?php echo $topPost->title; ?></span></div>
            </div>
        </a>
    </li>
<?php endfor; ?>           
</ul>
<?php endif; ?>
<div id="post-box">
<div><span class="icard">Bài viết mới</span></div>
<style>
.spot img {
    width: 24px;
    height: 24px;
    border-radius: 100px;
    margin-right: 3px;
    top: 7px;
}
</style>
<div class="post-box-item" style="margin-right: 2px;">
  <?php while($this->next()): ?>
    <?php if($this->category != "gallery"): ?>
      <?php if ($this->fields->stylelist == 'ying'): ?>
        <?php if($this->fields->description){$description = $this->fields->description;}else{ $description = $this->excerpt;} ?>
        <div class="item-in post-card-1 <?php if($this->hidden){echo 'jiami cursor md-trigger';} ?>" <?php if($this->hidden){echo 'data-modal="jiami" data-url='.Typecho_Widget::widget('Widget_Security')->getTokenUrl($this->permalink);} ?> >
        <div class="post-box-1">
        <a class="recent-img" href="<?php $this->permalink(); ?>">
            <div class="recent-cover wh-100"><img class="lazy transform wh-100" src="<?php echo $this->options->lazyimg ?>" data-original="<?php echo showCover($this); ?>" alt="<?php $this->title(); ?>"></div>
        </a>
        <div class="recent-info">
            <a href="<?php $this->permalink(); ?>">
                <a class="recent-title rt2 h-1x" href="<?php $this->permalink(); ?>"><?php $this->title(); ?></a>
                <div class="recent-desc">
                    <a style="@media (max-width: 500px).rt1, .recent-desc, .a-summary{display: none;}" class="recent-title rt1 h-1x" href="<?php $this->permalink(); ?>"><?php $this->title(); ?></a>
                    <span class="h-2px"><?php echo parseBiaoQing($description); ?></span>
                </div>
            </a>
            <div class="ls-r"><a href="<?php $this->permalink(); ?>"></a><a class="post-label" href="<?php echo $this->categories[0]["permalink"]; ?>" title="Xem thêm các bài khác"><svg class="ying" aria-hidden="true"><use xlink:href="#ying-xinyongka"></use></svg>&nbsp;<?php echo $this->categories[0]["name"]; ?></a>
            <span><?php if($this->tags){for($i=0;$i<count($this->tags);$i++){echo '<span class="tags-list"><svg class="ying" aria-hidden="true"><use xlink:href="#ying-biaoqian"></use></svg> '.$this->tags[$i]["name"].'</span>';}}?></span>
        </div>
            <div class="post-detail">
                <span class="spot"><img src="<?php $this->options->avatar() ?>"><?php $this->author();?></span><span><?php echo timesince($this->created); ?></span>
                <div class="post-detail2"><span class="pl-time"><i class="fa fa-clock-o"></i>&nbsp;<?php echo date("d-m-Y", $this->created);?></span><span><i class="fa fa-eye fs-16"></i>&nbsp;<?php echo getViews($this->cid); ?></span><span><i class="fa fa-commenting"></i>&nbsp;<?php $this->commentsNum(); ?></span></div>
            </div>
        </div>
    </div>
</div>

      <?php elseif ($this->fields->stylelist == 'new'): ?>
        <?php if($this->fields->description){$description = $this->fields->description;}else{ $description = $this->excerpt;} ?>
        <div class="item-in panel-small single-post box-shadow-wrap-normal tt-small-blur">
            <div class="index-post-img-small post-feature index-img-small tt-left-box">
                <a href="<?php $this->permalink(); ?>">
                    <div class="item-thumb-small lazy tt-left-img" style="background-image: url(<?php echo showCover($this); ?>)"></div>
                </a>
            </div>
            <div class="tt-blur-img" style="background-image: url(<?php echo showCover($this); ?>)"></div>
            <div class="post-meta wrapper-lg">
                <h2 class="m-t-none text-ellipsis index-post-title text-title"><a style="color: #fff;" href="<?php $this->permalink(); ?>"><?php $this->title(); ?></a></h2>
                <p class="summary l-h-2x text-muted" style="height: 66px;"><?php echo parseBiaoQing($description); ?>...</p>
                <div class="ls-r" style="margin-bottom:13px;"><a href="<?php $this->permalink(); ?>"></a>

  <a class="post-label" style="background:rgba(<?php echo (rand(150, 200)); ?>,<?php echo (rand(150, 255)); ?>,<?php echo (rand(150, 255)); ?>,.5)" href="<?php echo $this->categories[0]["permalink"]; ?>" title="Xem thêm các bài khác"><svg class="ying" aria-hidden="true"><use xlink:href="#ying-xinyongka"></use></svg>&nbsp;<?php echo $this->categories[0]["name"]; ?></a>

            <span> <?php if($this->tags){for($i=0;$i<count($this->tags);$i++){echo '<span class="tags-list"  style="background:rgba(<?php echo rand(150, 200); ?>,<?php echo rand(150, 255); ?>,<?php echo rand(150, 255); ?>,.5)"><svg class="ying" aria-hidden="true"><use xlink:href="#ying-biaoqian"></use></svg> '.$this->tags[$i]["name"].'</span>';}}?></span>
        </div>
                <div class="line line-lg b-b b-light"></div>
                <div class="text-muted post-item-foot-icon text-ellipsis list-inline">
                    <li><span class="m-r-sm right-small-icons"><i class="fa fa-user"></i></span>&nbsp;<?php $this->author();?></li>
                    <li><span class="right-small-icons m-r-sm"><i class="fa fa-calendar"></i></span>&nbsp;<?php echo timesince($this->created); ?></li>
                    <li><span class="right-small-icons m-r-sm"><i class="fa fa-eye"></i></span>&nbsp;<?php echo getViews($this->cid); ?> lượt xem</li>
                </div>
            </div>
        </div>
      <?php endif; ?>
    <?php endif; ?>
  <?php endwhile; ?>
</div>

<a class="more-btn xcenter cursor loadmore">Nhấp để tải thêm...</a>
</div>
<div class="nextpost"><?php $this->pageLink('下一页','next'); ?></div>

