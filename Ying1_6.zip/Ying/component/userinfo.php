<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>

<div class="card-widget">
<div class="weat">
                        <div class="cabout">
                            <div class="cabout_img">
                                <img src="<?php $this->options->sidebg(); ?>" alt="">
                            </div>
                            <div class="cabout_box">
                                <div class="cabout_frame">
                                    <div class="cabout_frame_name"><?php $this->author(); ?></div>
                                    <?php if($this->options->status): ?>
                                    <div class="cabout_frame_qm"><?php $this->options->status(); ?></div>
                                    <?php endif; ?>
                                </div>
                                <div class="cabout_box_tx">
                                    <img src="<?php $this->options->avatar() ?>">
                                </div>
                            </div>
                        </div>
                    </div>

    <?php if ($this->options->SocialInfo && (($this->options->SocialSwitch === 'on') || ($this->options->SocialSwitch === 'on2'))) : ?>
        <?php
        $SocialInfo = $this->options->SocialInfo;
        if ($SocialInfo) {
            $SocialInfo_arr = explode("\r\n", $SocialInfo);
            if (count($SocialInfo_arr) > 0) {
                for ($i = 0; $i < count($SocialInfo_arr); $i++) {
                    $QQ = explode("||", $SocialInfo_arr[$i])[0];
                    $WeChat = explode("||", $SocialInfo_arr[$i])[1];
                    $BiliBili = explode("||", $SocialInfo_arr[$i])[2];
                    $Weibo = explode("||", $SocialInfo_arr[$i])[3];
                }
            }
        }
        ?>
        <section class="top-social">
            <li>
                <a href="https://wpa.qq.com/msgrd?v=3&amp;uin=<?php echo trim($QQ) ?>&amp;site=qq&amp;menu=yes" target="_blank" title="QQ">
                    <img src="https://imgcache.qq.com/qzone/openapi/favicon.ico" />
                </a>
            </li>
            <li class="wechat">
                <a href="javascript:;" title=微信>
                    <img src="https://res.wx.qq.com/a/wx_fed/assets/res/NTI4MWU5.ico" />
                </a>
                <div class="wechatInner">
                    <img src="<?php echo trim($WeChat) ?>" />
                </div>
            </li>
            <li>
                <a href="https://space.bilibili.com/<?php echo trim($BiliBili) ?>" target="_blank" title="哔哩哔哩">
                    <img src="https://www.bilibili.com/favicon.ico" />
                </a>
            </li>
            <li>
                <a href="https://weibo.com/u/<?php echo trim($Weibo) ?>" target="_blank" title="微博">
                    <img src="https://weibo.com/favicon.ico" />
                </a>
            </li>
       </section> 
    <?php endif; ?>
                 </div>